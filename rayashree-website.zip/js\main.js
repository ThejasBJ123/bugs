/**
 * Rayashree Weaving Pvt. Ltd. - Master Client Script
 */

function resolveAssetPath(path) {
  if (!path) {
    const isSub = window.location.pathname.includes('/public/') || window.location.pathname.includes('/admin/');
    return isSub ? '../assets/images/bags.jpg' : 'assets/images/bags.jpg';
  }
  if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('data:')) {
    return path;
  }
  const isSub = window.location.pathname.includes('/public/') || window.location.pathname.includes('/admin/');
  if (isSub && !path.startsWith('../') && !path.startsWith('/')) {
    return '../' + path;
  }
  if (!isSub && path.startsWith('../')) {
    return path.replace(/^\.\.\//, '');
  }
  return path;
}

function initApp() {
  try { initPreloader(); } catch (e) { console.error("initPreloader error:", e); }
  try { initNavbar(); } catch (e) { console.error("initNavbar error:", e); }
  try { initRFQModal(); } catch (e) { console.error("initRFQModal error:", e); }
  try { initProductSpecsModal(); } catch (e) { console.error("initProductSpecsModal error:", e); }
  try { initProductThumbBar(); } catch (e) { console.error("initProductThumbBar error:", e); }
  try { initProductGrid(); } catch (e) { console.error("initProductGrid error:", e); }
  try { initContactPageForm(); } catch (e) { console.error("initContactPageForm error:", e); }
  try { applyDynamicSiteContent(); } catch (e) { console.error("applyDynamicSiteContent error:", e); }
  try { populateRFQSelect(); } catch (e) { console.error("populateRFQSelect error:", e); }
  try { renderPublicTestimonials(); } catch (e) { console.error("renderPublicTestimonials error:", e); }
  try { initFeedbackModal(); } catch (e) { console.error("initFeedbackModal error:", e); }
  try { initPackagingConfigurator(); } catch (e) { console.error("initPackagingConfigurator error:", e); }
  try { initCustomizerModal(); } catch (e) { console.error("initCustomizerModal error:", e); }
  try { initBackToTopButton(); } catch (e) { console.error("initBackToTopButton error:", e); }

  // Sync products from server (for Hostinger or multi-device browsing)
  if (typeof syncServerProducts === "function") {
    syncServerProducts(() => {
      try { initProductThumbBar(); } catch (e) {}
      try { initProductGrid(); } catch (e) {}
      try { applyDynamicSiteContent(); } catch (e) {}
      try { populateRFQSelect(); } catch (e) {}
      try { renderPublicTestimonials(); } catch (e) {}
    });
  }
  
  // Track pageview for Admin analytics
  if (typeof trackPageView === "function") {
    try {
      const pageName = document.title ? document.title.split("|")[0].trim() : window.location.pathname;
      trackPageView(pageName);
    } catch (e) {}
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initApp);
} else {
  initApp();
}

// Instant live re-render when admin updates products in another tab
window.addEventListener("storage", (e) => {
  if (e.key === "rw_products" || e.key === "rw_site_content" || e.key === "rw_company_info" || e.key === "rw_testimonials") {
    try { initProductThumbBar(); } catch (err) {}
    try { initProductGrid(); } catch (err) {}
    try { applyDynamicSiteContent(); } catch (err) {}
    try { populateRFQSelect(); } catch (err) {}
    try { renderPublicTestimonials(); } catch (err) {}
  }
});

/* ==========================================================================
   Dynamic CMS Site Content & Products Hydration
   ========================================================================== */

function applyDynamicSiteContent() {
  if (typeof getCompanyInfo !== "function" || typeof getSiteContent !== "function") return;

  const company = getCompanyInfo();
  const content = getSiteContent();
  const products = typeof getProducts === "function" ? getProducts() : [];

  // 1. Dynamic Logo & Brand Identity Replacement
  if (company && (company.logo || company.logoWhite)) {
    const customLogo = company.logo || company.logoWhite;
    const brandLogoImgs = document.querySelectorAll(".brand-logo img, .footer-brand img, .header-brand img, .nav-brand img");
    brandLogoImgs.forEach(img => {
      img.src = resolveAssetPath(customLogo);
    });
  }

  // Update dynamic product count across headers and nav links
  const prodCount = products.length;
  
  const navProductLinks = document.querySelectorAll("a.nav-link[href*='products.html']");
  navProductLinks.forEach(link => {
    link.textContent = `Products`;
  });

  const countBadges = document.querySelectorAll(".products-count-badge, .dynamic-prod-count");
  countBadges.forEach(el => {
    el.textContent = prodCount;
  });

  const countHeadings = document.querySelectorAll(".dynamic-prod-heading");
  countHeadings.forEach(el => {
    el.textContent = `Specialized Product Categories`;
  });

  // 2. Company Contact Details across Topbar, Contact Sections & Footers
  const phoneLinks = document.querySelectorAll("a[href^='tel:']");
  phoneLinks.forEach(a => {
    a.href = `tel:${company.whatsappNumber || '919108713258'}`;
    if (a.textContent.includes("+91") || a.textContent.includes("9108713258")) {
      a.textContent = company.phone;
    }
  });

  const emailLinks = document.querySelectorAll("a[href^='mailto:']");
  emailLinks.forEach(a => {
    a.href = `mailto:${company.email}`;
    if (a.textContent.includes("@")) {
      a.textContent = company.email;
    }
  });

  const waLinks = document.querySelectorAll("a[href*='wa.me']");
  const waNum = company.whatsappNumber || '919108713258';
  waLinks.forEach(a => {
    if (a.classList.contains("floating-whatsapp")) {
      a.href = `https://wa.me/${waNum}?text=Hello%20Rayashree%20Weaving,%20I%20am%20interested%20in%20your%20products.`;
      if (!a.querySelector(".wa-tooltip")) {
        const tip = document.createElement("span");
        tip.className = "wa-tooltip";
        tip.textContent = "Chat on WhatsApp";
        a.appendChild(tip);
      }
    }
  });

  if (company.shortAddress || company.address) {
    const topLocationItems = document.querySelectorAll(".top-bar-item .fa-location-dot ~ span");
    topLocationItems.forEach(span => {
      span.textContent = company.shortAddress || "Kenchanapur Village, Kengeri Hobli, Bengaluru - 560060";
    });

    const footerLocationItems = document.querySelectorAll(".footer-contact-item .fa-location-dot ~ span");
    footerLocationItems.forEach(span => {
      span.textContent = company.shortAddress || "Kenchanapur Village, Kengeri Hobli, Bengaluru - 560060";
    });
  }

  // 3. Home Page Hero & Stats (if on index.html)
  if (content && content.home) {
    const heroTag = document.querySelector(".hero-tag");
    if (heroTag && content.home.heroTag) heroTag.textContent = content.home.heroTag;

    const heroTitle = document.querySelector(".hero-title");
    if (heroTitle && content.home.heroTitle) heroTitle.textContent = content.home.heroTitle;

    const heroSubtitle = document.querySelector(".hero-subtitle");
    if (heroSubtitle && content.home.heroSubtitle) heroSubtitle.textContent = content.home.heroSubtitle;

    const statCards = document.querySelectorAll(".stat-card, .stat-item");
    if (statCards.length >= 4) {
      if (content.home.stat1Val) {
        const num = statCards[0].querySelector(".stat-number");
        const lbl = statCards[0].querySelector(".stat-label");
        if (num) num.textContent = content.home.stat1Val;
        if (lbl) lbl.textContent = content.home.stat1Label;
      }
      if (content.home.stat2Val) {
        const num = statCards[1].querySelector(".stat-number");
        const lbl = statCards[1].querySelector(".stat-label");
        if (num) num.textContent = content.home.stat2Val || "48+ Looms";
        if (lbl) lbl.textContent = content.home.stat2Label || "High-Speed Circular Looms";
      }
      if (content.home.stat3Val) {
        const num = statCards[2].querySelector(".stat-number");
        const lbl = statCards[2].querySelector(".stat-label");
        if (num) num.textContent = content.home.stat3Val;
        if (lbl) lbl.textContent = content.home.stat3Label;
      }
      if (content.home.stat4Val) {
        const num = statCards[3].querySelector(".stat-number");
        const lbl = statCards[3].querySelector(".stat-label");
        if (num) num.textContent = content.home.stat4Val;
        if (lbl) lbl.textContent = content.home.stat4Label;
      }
    }
  }

  // 4. Products Page Dynamic Content (if on products.html)
  if (content && content.products && window.location.pathname.includes("products.html")) {
    const h1 = document.querySelector("h1");
    if (h1 && content.products.heroTitle) h1.textContent = content.products.heroTitle;
    
    const heroP = document.querySelector("h1 + p");
    if (heroP && content.products.heroSubtitle) heroP.textContent = content.products.heroSubtitle;
  }

  // 5. About Us Page Dynamic Content (if on about.html)
  if (content && content.about && window.location.pathname.includes("about.html")) {
    const h2Hero = document.querySelector(".section-tag-emerald + h2");
    if (h2Hero && content.about.heading) h2Hero.textContent = content.about.heading;

    const ceoQuote = document.querySelector(".executive-grid p");
    if (ceoQuote && content.about.ceoMessage) ceoQuote.textContent = `"${content.about.ceoMessage}"`;
  }

  // 6. Infrastructure Page Dynamic Content (if on infrastructure.html)
  if (content && content.infrastructure && window.location.pathname.includes("infrastructure.html")) {
    const h1 = document.querySelector("h1");
    if (h1 && content.infrastructure.heading) h1.textContent = content.infrastructure.heading;

    const heroP = document.querySelector("h1 + p");
    if (heroP && content.infrastructure.subheading) heroP.textContent = content.infrastructure.subheading;
  }

  // 7. Contact Page Dynamic Content (if on contact.html)
  if (company && window.location.pathname.includes("contact.html")) {
    const ceoNameEl = document.querySelector(".fa-user-tie ~ div > div:first-child");
    if (ceoNameEl && company.ceo) ceoNameEl.textContent = company.ceo;
  }
}

/* ==========================================================================
   Navigation & Mobile Menu
   ========================================================================== */

function initNavbar() {
  const mobileToggle = document.getElementById("mobileToggle");
  const navMenu = document.getElementById("navMenu");

  if (mobileToggle && navMenu) {
    const toggleMenu = (open) => {
      const shouldOpen = open !== undefined ? open : !navMenu.classList.contains("active");
      if (shouldOpen) {
        navMenu.classList.add("active");
        document.body.style.overflow = "hidden";
      } else {
        navMenu.classList.remove("active");
        document.body.style.overflow = "";
      }
      const icon = mobileToggle.querySelector("i");
      if (icon) {
        icon.className = shouldOpen ? "fa-solid fa-xmark" : "fa-solid fa-bars";
      }
    };

    mobileToggle.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleMenu();
    });

    // Close menu when clicking nav links
    const navLinks = navMenu.querySelectorAll(".nav-link");
    navLinks.forEach(link => {
      link.addEventListener("click", () => {
        toggleMenu(false);
      });
    });

    // Close menu when clicking outside
    document.addEventListener("click", (e) => {
      if (navMenu.classList.contains("active") && !navMenu.contains(e.target) && !mobileToggle.contains(e.target)) {
        toggleMenu(false);
      }
    });
  }

  // Header scroll shadow effect
  const header = document.querySelector(".main-header");
  if (header) {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 20) {
        header.style.boxShadow = "0 10px 30px rgba(0,0,0,0.12)";
      } else {
        header.style.boxShadow = "0 4px 20px rgba(0,0,0,0.06)";
      }
    });
  }
}

/* ==========================================================================
   Floating Back to Top Button
   ========================================================================== */

function initBackToTopButton() {
  let btn = document.getElementById("backToTopBtn");
  if (!btn) {
    btn = document.createElement("button");
    btn.id = "backToTopBtn";
    btn.className = "floating-back-to-top";
    btn.setAttribute("aria-label", "Back to top");
    btn.setAttribute("title", "Back to top");
    btn.innerHTML = `<i class="fa-solid fa-chevron-up"></i><span class="top-tooltip">Back to Top</span>`;
    document.body.appendChild(btn);
  }

  const toggleVisibility = () => {
    if (window.scrollY > 280) {
      btn.classList.add("visible");
    } else {
      btn.classList.remove("visible");
    }
  };

  window.addEventListener("scroll", toggleVisibility, { passive: true });
  toggleVisibility();

  btn.addEventListener("click", (e) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  });
}

/* ==========================================================================
   Toast Notification System
   ========================================================================== */

function showToast(message, iconClass = "fa-solid fa-circle-check", duration = 4000) {
  let container = document.getElementById("toastContainer");
  if (!container) {
    container = document.createElement("div");
    container.id = "toastContainer";
    container.className = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `<i class="${iconClass}" style="color: var(--gold-400); font-size: 1.25rem;"></i> <span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(-100%)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

/* ==========================================================================
   Dynamic RFQ Product Select Options Hydration
   ========================================================================== */

function populateRFQSelect() {
  const select = document.getElementById("rfqProduct");
  if (!select || typeof getProducts !== "function") return;

  const products = getProducts();
  const currentValue = select.value;
  select.innerHTML = "";

  products.forEach((prod) => {
    const opt = document.createElement("option");
    opt.value = prod.name;
    opt.textContent = prod.name;
    select.appendChild(opt);
  });

  const customOpt = document.createElement("option");
  customOpt.value = "Custom Packaging Requirement";
  customOpt.textContent = "Custom Bespoke Packaging Specification";
  select.appendChild(customOpt);

  if (currentValue) {
    for (let opt of select.options) {
      if (opt.value === currentValue) {
        opt.selected = true;
        break;
      }
    }
  }
}

/* ==========================================================================
   RFQ Modal & Inquiry Handler
   ========================================================================== */

function initRFQModal() {
  const modal = document.getElementById("rfqModal");
  if (!modal) return;

  const closeBtns = modal.querySelectorAll(".modal-close-trigger");
  closeBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      closeRFQModal();
    });
  });

  modal.addEventListener("click", (e) => {
    if (e.target === modal) {
      closeRFQModal();
    }
  });

  const rfqForm = document.getElementById("rfqForm");
  if (rfqForm) {
    rfqForm.addEventListener("submit", (e) => {
      e.preventDefault();
      
      const clientName = document.getElementById("rfqName").value.trim();
      const phone = document.getElementById("rfqPhone").value.trim();
      const email = document.getElementById("rfqEmail").value.trim();
      const product = document.getElementById("rfqProduct").value;
      const quantity = document.getElementById("rfqQuantity").value.trim();
      const specifications = document.getElementById("rfqSpecs").value.trim();

      if (!clientName || !phone || !product) {
        alert("Please fill in your name, contact phone, and product category.");
        return;
      }

      const newInquiry = addInquiry({
        clientName: clientName,
        contactPerson: clientName,
        phone: phone,
        email: email || "N/A",
        product: product,
        quantity: quantity || "Custom Requirement",
        specifications: specifications || "Standard Factory Specification",
        priority: "High"
      });

      // Dispatch to Hostinger PHP backend if hosted on server
      try {
        const apiEndpoint = (typeof getApiEndpoint === 'function' ? getApiEndpoint('api/send-inquiry.php') : ((window.location.pathname.includes('/public/') || window.location.pathname.includes('/admin/')) ? '../api/send-inquiry.php' : 'api/send-inquiry.php'));
        fetch(apiEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            clientName: clientName,
            phone: phone,
            email: email,
            product: product,
            quantity: quantity,
            specifications: specifications
          })
        }).catch(() => {});
      } catch (e) {}

      closeRFQModal();
      rfqForm.reset();

      showToast(`Redirecting to WhatsApp with your quote request...`);

      // Directly redirect to WhatsApp with full structured details
      const waNumber = (typeof COMPANY_INFO !== 'undefined' && COMPANY_INFO.whatsappNumber) ? COMPANY_INFO.whatsappNumber : "919108713258";
      const lines = [
        `*Rayashree Weaving - Quotation Request*`,
        ``,
        `📦 *Product:* ${product}`,
        `📊 *Quantity:* ${quantity || "Custom Requirement"}`,
        `📝 *Specifications / Details:* ${specifications || "Standard Factory Specs"}`,
        ``,
        `👤 *Client Details:*`,
        `• *Name / Company:* ${clientName}`,
        `• *Phone:* ${phone}`,
        `• *Email:* ${email || "N/A"}`,
        `• *RFQ Reference:* #${newInquiry.id}`,
        ``,
        `Please provide best factory pricing and availability.`
      ];
      const msg = encodeURIComponent(lines.join("\n"));
      const waUrl = `https://wa.me/${waNumber}?text=${msg}`;

      setTimeout(() => {
        window.open(waUrl, "_blank");
      }, 350);
    });
  }
}

function initContactPageForm() {
  const contactForm = document.getElementById("contactPageForm");
  if (!contactForm) return;

  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("cName") ? document.getElementById("cName").value.trim() : "";
    const phone = document.getElementById("cPhone") ? document.getElementById("cPhone").value.trim() : "";
    const email = document.getElementById("cEmail") ? document.getElementById("cEmail").value.trim() : "";
    const product = document.getElementById("cProduct") ? document.getElementById("cProduct").value : "General Inquiry";
    const message = document.getElementById("cMessage") ? document.getElementById("cMessage").value.trim() : "";

    if (!name || !phone) {
      alert("Please provide your name and phone number.");
      return;
    }

    const newInquiry = addInquiry({
      clientName: name,
      contactPerson: name,
      phone: phone,
      email: email || "N/A",
      product: product,
      quantity: "Standard Order",
      specifications: message || "Direct Inquiry from Contact Page",
      priority: "High"
    });

    // Dispatch to Hostinger PHP backend if hosted on server
    try {
      const apiEndpoint = (typeof getApiEndpoint === 'function' ? getApiEndpoint('api/send-inquiry.php') : ((window.location.pathname.includes('/public/') || window.location.pathname.includes('/admin/')) ? '../api/send-inquiry.php' : 'api/send-inquiry.php'));
      fetch(apiEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName: name,
          phone: phone,
          email: email,
          product: product,
          quantity: "Standard Order",
          specifications: message
        })
      }).catch(() => {});
    } catch (e) {}

    contactForm.reset();
    showToast(`Redirecting to WhatsApp with your inquiry...`);

    // Directly redirect to WhatsApp with full structured details
    const waNumber = (typeof COMPANY_INFO !== 'undefined' && COMPANY_INFO.whatsappNumber) ? COMPANY_INFO.whatsappNumber : "919108713258";
    const lines = [
      `*Rayashree Weaving - Website Inquiry*`,
      ``,
      `📦 *Product / Requirement:* ${product}`,
      `📝 *Message / Details:* ${message || "Direct Inquiry from Contact Page"}`,
      ``,
      `👤 *Client Details:*`,
      `• *Name:* ${name}`,
      `• *Phone:* ${phone}`,
      `• *Email:* ${email || "N/A"}`,
      `• *Inquiry Reference:* #${newInquiry.id}`,
      ``,
      `Please get in touch regarding this requirement.`
    ];
    const msg = encodeURIComponent(lines.join("\n"));
    const waUrl = `https://wa.me/${waNumber}?text=${msg}`;

    setTimeout(() => {
      window.open(waUrl, "_blank");
    }, 350);
  });
}

function openRFQModal(productName = "") {
  const waNumber = (typeof COMPANY_INFO !== 'undefined' && COMPANY_INFO.whatsappNumber) ? COMPANY_INFO.whatsappNumber : "919108713258";
  
  let text = "";
  if (productName && typeof productName === 'string' && productName.trim()) {
    const products = (typeof getProducts === 'function') ? getProducts() : [];
    const prod = products.find(p => (p.name && p.name.toLowerCase() === productName.toLowerCase()) || p.id === productName);
    
    if (prod) {
      text = `Hello Rayashree (Rayashree Weaving),\n\nI would like to request a direct factory quotation and specifications for:\n📦 *Product:* ${prod.name}\n📂 *Category:* ${prod.category || 'Industrial Packaging'}\n⚖️ *Capacity / Load:* ${prod.capacityRange || 'Custom'}\n🧵 *GSM Weight:* ${prod.gsmRange || 'Standard'}\n\nPlease share current factory pricing, minimum order quantity, and delivery timeline.`;
    } else {
      text = `Hello Rayashree (Rayashree Weaving),\n\nI would like to request a quotation for *${productName.trim()}*.\n\nPlease share current factory pricing and delivery timeline.`;
    }
  } else {
    text = `Hello Rayashree (Rayashree Weaving),\n\nI would like to request a direct factory quotation for bulk industrial woven packaging & sacks.\n\nPlease share your product catalog and pricing.`;
  }

  const waUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(text)}`;
  window.open(waUrl, "_blank");
}

function closeRFQModal() {
  const modal = document.getElementById("rfqModal");
  if (modal) {
    modal.classList.remove("active");
    document.body.style.overflow = "";
  }
}

/* ==========================================================================
   Dynamic Quick Visual Product Thumbnail Bar Rendering
   ========================================================================== */

function initProductThumbBar() {
  const bar = document.getElementById("productThumbBar") || document.querySelector(".product-thumb-bar");
  if (!bar || typeof getProducts !== "function") return;

  const products = getProducts();
  if (products.length === 0) {
    bar.style.display = "none";
    return;
  }
  bar.style.display = "grid";
  bar.innerHTML = "";

  products.forEach((prod) => {
    const item = document.createElement("div");
    item.style.cursor = "pointer";
    item.style.background = "var(--white)";
    item.style.border = "1.5px solid var(--dark-200)";
    item.style.borderRadius = "var(--radius-md)";
    item.style.padding = "0.75rem";
    item.style.textAlign = "center";
    item.style.transition = "all var(--transition-normal)";
    item.style.boxShadow = "var(--shadow-sm)";

    item.onmouseover = () => {
      item.style.borderColor = "var(--gold-500)";
      item.style.transform = "translateY(-3px)";
      item.style.boxShadow = "var(--shadow-md)";
    };
    item.onmouseout = () => {
      item.style.borderColor = "var(--dark-200)";
      item.style.transform = "translateY(0)";
      item.style.boxShadow = "var(--shadow-sm)";
    };

    const linkTarget = `javascript:openProductSpecsModal('${prod.id}')`;

    item.innerHTML = `
      <a href="${linkTarget}" style="text-decoration: none; color: inherit; display: block;">
        <img src="${resolveAssetPath(prod.image)}" alt="${prod.name}" style="width: 100%; height: 75px; object-fit: cover; border-radius: var(--radius-sm); margin-bottom: 0.4rem;" onerror="this.src='${resolveAssetPath('assets/images/bags.jpg')}'">
        <strong style="font-size: 0.8rem; color: var(--primary-900); display: block; line-height: 1.2; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
          ${prod.shortName || prod.name}
        </strong>
      </a>
    `;

    bar.appendChild(item);
  });
}

/* ==========================================================================
   Dynamic Product Showcase Grid & Dynamic Filter Bar
   ========================================================================== */

function initProductGrid() {
  const container = document.getElementById("productShowcaseGrid");
  if (!container) return;

  let products = (typeof getProducts === "function") ? getProducts() : [];
  if (!products || products.length === 0) {
    if (typeof DEFAULT_PRODUCTS !== "undefined" && DEFAULT_PRODUCTS.length > 0) {
      products = DEFAULT_PRODUCTS;
      try { localStorage.setItem("rw_products", JSON.stringify(DEFAULT_PRODUCTS)); } catch(e){}
    }
  }

  const filterBar = document.getElementById("productFilterBar") || document.querySelector(".product-filter-bar");

  if (!products || products.length === 0) {
    // If container already has static HTML products, preserve them!
    if (container.children.length > 0) return;
    if (filterBar) filterBar.style.display = "none";
    return;
  }

  // Extract unique categories
  const categories = [...new Set(products.map(p => p.category ? p.category.trim() : "").filter(Boolean))];

  if (filterBar) {
    if (categories.length <= 1) {
      filterBar.style.display = "none";
    } else {
      filterBar.style.display = "flex";
      filterBar.innerHTML = "";

      // "All Products" button
      const allBtn = document.createElement("button");
      allBtn.className = "filter-btn active";
      allBtn.setAttribute("data-filter", "All");
      allBtn.textContent = `All Products (${products.length})`;
      filterBar.appendChild(allBtn);

      // Category Filter Buttons
      categories.forEach((cat) => {
        const btn = document.createElement("button");
        btn.className = "filter-btn";
        btn.setAttribute("data-filter", cat);
        btn.textContent = cat;
        filterBar.appendChild(btn);
      });

      const filterBtns = filterBar.querySelectorAll(".filter-btn");
      filterBtns.forEach(btn => {
        btn.addEventListener("click", () => {
          filterBtns.forEach(b => b.classList.remove("active"));
          btn.classList.add("active");
          renderGrid(btn.getAttribute("data-filter"));
        });
      });
    }
  }

  function renderGrid(filterKey = "All") {
    container.innerHTML = "";
    
    const filtered = (filterKey === "All" || !filterKey)
      ? products 
      : products.filter(p => {
          const key = filterKey.toLowerCase().trim();
          return (p.category && p.category.toLowerCase().trim() === key) ||
                 (p.category && p.category.toLowerCase().includes(key)) ||
                 (p.name && p.name.toLowerCase().includes(key));
        });

    if (filtered.length === 0) {
      container.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--dark-500); font-weight: 600;">No products found in this category.</div>`;
      return;
    }

    filtered.forEach((prod) => {
      const card = document.createElement("div");
      card.className = "product-card";

      card.innerHTML = `
        <div class="product-card-img" onclick="openProductSpecsModal('${prod.id}')" style="cursor: pointer;">
          <img src="${resolveAssetPath(prod.image)}" alt="${prod.name}" loading="lazy" onerror="this.src='${resolveAssetPath('assets/images/bags.jpg')}'">
          <span class="product-badge">${prod.shortName || prod.badge || prod.name}</span>
        </div>
        <div class="product-card-body">
          <span class="product-category">${prod.category || "Industrial Packaging"}</span>
          <h3 class="product-title" onclick="openProductSpecsModal('${prod.id}')" style="cursor: pointer;">${prod.name}</h3>
          <p class="product-tagline">${prod.tagline || "Heavy-Duty Precision Woven Packaging Solution."}</p>
          
          <div class="product-specs-preview">
            <div class="spec-preview-item">
              <span class="spec-preview-label">Capacity / Load:</span>
              <span class="spec-preview-val">${prod.capacityRange || "Custom Sizing"}</span>
            </div>
            <div class="spec-preview-item">
              <span class="spec-preview-label">GSM Weight:</span>
              <span class="spec-preview-val">${prod.gsmRange || "50 - 250 GSM"}</span>
            </div>
          </div>

          <div class="product-card-footer">
            <button class="btn btn-customize-prod" onclick="openCustomizerModal('${prod.id}')">
              <i class="fa-solid fa-sliders"></i> Customize Product
            </button>
            <button class="btn btn-specs-prod" onclick="openProductSpecsModal('${prod.id}')">
              <i class="fa-solid fa-circle-info"></i> View Full Specs
            </button>
            <a href="https://wa.me/919108713258?text=${encodeURIComponent(`Hello Rayashree (Rayashree Weaving),\n\nI want to order / inquire about *${prod.name}*.\n• *Category:* ${prod.category || 'Industrial Packaging'}\n• *Capacity / Load:* ${prod.capacityRange || 'Custom'}\n• *GSM Weight:* ${prod.gsmRange || 'Standard'}\n\nPlease share current factory pricing and dispatch timeline.`)}" target="_blank" class="btn btn-whatsapp-prod">
              <i class="fa-brands fa-whatsapp"></i> Buy / Inquire on WhatsApp
            </a>
          </div>

        </div>
      `;
      container.appendChild(card);
    });
  }

  renderGrid("All");
}

/* ==========================================================================
   Product Specs & Technical Details Modal Handler
   ========================================================================== */

function initProductSpecsModal() {
  let modal = document.getElementById("productSpecsModal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "productSpecsModal";
    modal.className = "modal-backdrop";
    modal.innerHTML = `
      <div class="modal-card" style="max-width: 780px; max-height: 90vh; overflow-y: auto;">
        <div class="modal-header">
          <h3 id="specsModalTitle" style="color: #ffffff; display: flex; align-items: center; gap: 0.5rem;">
            <i class="fa-solid fa-box-open text-gold"></i> Product Specifications
          </h3>
          <button class="modal-close-btn" onclick="closeProductSpecsModal()"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body" id="specsModalBody">
          <!-- Populated dynamically -->
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeProductSpecsModal();
    });
  }
}

function openProductSpecsModal(productId) {
  if (typeof getProducts !== "function") return;
  const products = getProducts();
  const prod = products.find(p => p.id === productId || p.slug === productId);
  if (!prod) return;

  initProductSpecsModal();
  const modal = document.getElementById("productSpecsModal");
  const modalTitle = document.getElementById("specsModalTitle");
  const modalBody = document.getElementById("specsModalBody");

  if (!modal || !modalBody) return;

  modalTitle.innerHTML = `<i class="fa-solid fa-box-open text-gold"></i> ${prod.name}`;

  // Build specs rows
  let specsHtml = "";
  if (prod.specifications && typeof prod.specifications === "object") {
    specsHtml = Object.entries(prod.specifications).map(([key, val]) => `
      <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--dark-200); font-size: 0.875rem;">
        <strong style="color: var(--dark-700);">${key}:</strong>
        <span style="color: var(--dark-900); font-weight: 600; text-align: right;">${val}</span>
      </div>
    `).join("");
  }

  // Build features list
  let featuresHtml = "";
  if (Array.isArray(prod.features) && prod.features.length > 0) {
    featuresHtml = prod.features.map(f => `
      <li style="display: flex; align-items: flex-start; gap: 0.6rem; color: var(--dark-800); font-size: 0.9rem; margin-bottom: 0.4rem;">
        <i class="fa-solid fa-circle-check text-emerald" style="margin-top: 3px;"></i> <span>${f}</span>
      </li>
    `).join("");
  }

  modalBody.innerHTML = `
    <div style="display: grid; grid-template-columns: 1.1fr 1fr; gap: 1.75rem; margin-bottom: 1.5rem; align-items: start;">
      <div>
        <div style="border-radius: 12px; overflow: hidden; border: 2px solid var(--gold-300); box-shadow: var(--shadow-md); margin-bottom: 1rem;">
          <img src="${resolveAssetPath(prod.image)}" alt="${prod.name}" style="width: 100%; height: 260px; object-fit: cover; display: block;" onerror="this.src='${resolveAssetPath('assets/images/bags.jpg')}'">
        </div>
        <div style="background: var(--dark-50); border: 1px solid var(--dark-200); border-radius: 10px; padding: 1rem;">
          <div style="font-size: 0.8rem; font-weight: 700; color: var(--gold-700); text-transform: uppercase; margin-bottom: 0.25rem;">Category</div>
          <div style="font-weight: 800; color: var(--primary-900);">${prod.category || "Industrial Manufacturing"}</div>
          <div style="font-size: 0.85rem; color: var(--dark-600); margin-top: 0.5rem;">${prod.tagline || ""}</div>
        </div>
      </div>

      <div>
        <h4 style="font-size: 1.05rem; font-weight: 800; color: var(--primary-900); margin-bottom: 0.75rem;">
          Technical Specifications
        </h4>
        <div style="background: var(--white); border: 1px solid var(--dark-200); border-radius: 10px; padding: 1rem; margin-bottom: 1.25rem;">
          <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--dark-200); font-size: 0.875rem;">
            <strong style="color: var(--dark-700);">Standard Capacity:</strong>
            <span style="color: var(--dark-900); font-weight: 700;">${prod.capacityRange || "Custom"}</span>
          </div>
          <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--dark-200); font-size: 0.875rem;">
            <strong style="color: var(--dark-700);">GSM Weight:</strong>
            <span style="color: var(--dark-900); font-weight: 700;">${prod.gsmRange || "50 - 250 GSM"}</span>
          </div>
          <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--dark-200); font-size: 0.875rem;">
            <strong style="color: var(--dark-700);">Polymer Material:</strong>
            <span style="color: var(--dark-900); font-weight: 600;">${prod.material || "100% Virgin Polymer"}</span>
          </div>
          ${specsHtml}
        </div>

        ${featuresHtml ? `
          <h4 style="font-size: 1.05rem; font-weight: 800; color: var(--primary-900); margin-bottom: 0.5rem;">
            Key Engineering Highlights
          </h4>
          <ul style="padding-left: 0; list-style: none; margin-bottom: 1.25rem;">
            ${featuresHtml}
          </ul>
        ` : ''}
      </div>
    </div>

    <div style="display: flex; gap: 1rem; border-top: 1px solid var(--dark-200); padding-top: 1.25rem; flex-wrap: wrap;">
      <button class="btn btn-gold btn-lg" onclick="closeProductSpecsModal(); openRFQModal('${prod.name}');" style="flex: 1.5;">
        <i class="fa-solid fa-calculator"></i> Request Direct Factory Quote
      </button>
      <a href="https://wa.me/919108713258?text=${encodeURIComponent(`Hello Rayashree (Rayashree Weaving),\n\nI am inquiring about *${prod.name}*.\n• *Category:* ${prod.category || 'Industrial Packaging'}\n• *Capacity / Load:* ${prod.capacityRange || 'Custom'}\n• *GSM Weight:* ${prod.gsmRange || 'Standard'}\n• *Material:* ${prod.material || '100% Virgin Polymer'}\n\nPlease provide pricing and minimum order quantity.`)}" target="_blank" class="btn btn-primary" style="flex: 1;">
        <i class="fa-brands fa-whatsapp"></i> Chat on WhatsApp
      </a>
    </div>
  `;

  modal.classList.add("active");
  document.body.style.overflow = "hidden";
}

function closeProductSpecsModal() {
  const modal = document.getElementById("productSpecsModal");
  if (modal) {
    modal.classList.remove("active");
    document.body.style.overflow = "";
  }
}

// Handle Browser Back button closing modals
window.addEventListener("popstate", (e) => {
  const modal = document.getElementById("rfqModal");
  if (modal && modal.classList.contains("active")) {
    modal.classList.remove("active");
    document.body.style.overflow = "";
  }
  closeProductSpecsModal();
});

// Handle ESC key closing modals
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" || e.keyCode === 27) {
    closeRFQModal();
    closeProductSpecsModal();
  }
});

/* ==========================================================================
   5-Second Intro Preloader Controller with Letter-by-Letter Animation
   ========================================================================== */

function initPreloader() {
  const preloader = document.getElementById("sitePreloader");
  if (!preloader) return;

  const titleElem = document.getElementById("animatedPreloaderTitle");
  if (titleElem && !titleElem.dataset.animated) {
    titleElem.dataset.animated = "true";
    const text = "RAYASHREE WEAVING PVT. LTD.";
    titleElem.innerHTML = "";
    
    [...text].forEach((char, index) => {
      const span = document.createElement("span");
      span.className = "letter" + (char === " " ? " space" : "") + (index < 9 ? " gold-char" : "");
      span.textContent = char === " " ? "\u00A0" : char;
      span.style.animationDelay = `${0.35 + index * 0.075}s`;
      titleElem.appendChild(span);
    });
  }

  const hidePreloader = () => {
    if (preloader.classList.contains("fade-out")) return;
    preloader.classList.add("fade-out");
    setTimeout(() => {
      preloader.style.display = "none";
    }, 850);
  };

  const autoHideTimer = setTimeout(hidePreloader, 5000);

  const skipBtn = document.getElementById("skipPreloaderBtn");
  if (skipBtn) {
    skipBtn.addEventListener("click", () => {
      clearTimeout(autoHideTimer);
      hidePreloader();
    });
  }
}

window.openRFQModal = openRFQModal;
window.openProductSpecsModal = openProductSpecsModal;
window.closeProductSpecsModal = closeProductSpecsModal;
window.closeRFQModal = closeRFQModal;
window.showToast = showToast;

/* ==========================================================================
   Client Testimonials & Feedback Dynamic Rendering & Form Submission
   ========================================================================== */

function renderPublicTestimonials() {
  const container = document.getElementById("testimonialsGrid");
  if (!container || typeof getApprovedTestimonials !== "function") return;

  const testimonials = getApprovedTestimonials();
  container.innerHTML = "";

  testimonials.forEach(item => {
    const card = document.createElement("div");
    card.style.cssText = "background: var(--white); padding: 2rem; border-radius: var(--radius-lg); border: 1px solid var(--dark-200); position: relative; display: flex; flex-direction: column; justify-content: space-between; box-shadow: var(--shadow-sm); transition: transform 0.2s ease, box-shadow 0.2s ease;";

    // Build star rating HTML
    const ratingNum = item.rating || 5;
    let starsHtml = "";
    for (let i = 1; i <= 5; i++) {
      if (i <= ratingNum) {
        starsHtml += `<i class="fa-solid fa-star" style="color: #f59e0b; margin-right: 2px;"></i>`;
      } else {
        starsHtml += `<i class="fa-regular fa-star" style="color: #cbd5e1; margin-right: 2px;"></i>`;
      }
    }

    card.innerHTML = `
      <div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
          <div style="color: var(--gold-500); font-size: 1.75rem;"><i class="fa-solid fa-quote-left"></i></div>
          <div style="font-size: 0.85rem;">${starsHtml}</div>
        </div>
        <p style="font-size: 0.95rem; color: var(--dark-700); line-height: 1.7; margin-bottom: 1.5rem; font-style: italic;">
          "${item.quote}"
        </p>
      </div>
      <div>
        <div style="font-weight: 800; color: var(--primary-900); font-size: 1.05rem;">${item.author}</div>
        <div style="font-size: 0.825rem; color: var(--gold-700); font-weight: 600; margin-top: 2px;">
          ${item.role ? item.role + ' • ' : ''}${item.company || ''}
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

function initFeedbackModal() {
  const modal = document.getElementById("feedbackModal");
  const form = document.getElementById("feedbackForm");
  if (!modal || !form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("feedbackAuthor")?.value?.trim();
    const role = document.getElementById("feedbackRole")?.value?.trim();
    const company = document.getElementById("feedbackCompany")?.value?.trim();
    const email = document.getElementById("feedbackEmail")?.value?.trim();
    const rating = document.getElementById("feedbackRating")?.value || 5;
    const quote = document.getElementById("feedbackQuote")?.value?.trim();

    if (!name || !quote) {
      alert("Please provide your name and your feedback message.");
      return;
    }

    if (typeof addFeedback === "function") {
      addFeedback({
        author: name,
        role: role || "Valued Client",
        company: company || "",
        email: email || "",
        rating: rating,
        quote: quote
      });
    }

    form.reset();
    closeFeedbackModal();
    if (typeof showToast === "function") {
      showToast("Thank you! Your feedback has been submitted for admin approval.");
    } else {
      alert("Thank you! Your feedback has been submitted for admin approval.");
    }
  });
}

function openFeedbackModal() {
  const modal = document.getElementById("feedbackModal");
  if (modal) {
    modal.classList.add("active");
    document.body.style.overflow = "hidden";
  }
}

function closeFeedbackModal() {
  const modal = document.getElementById("feedbackModal");
  if (modal) {
    modal.classList.remove("active");
    document.body.style.overflow = "";
  }
}

window.renderPublicTestimonials = renderPublicTestimonials;
window.initFeedbackModal = initFeedbackModal;
window.openFeedbackModal = openFeedbackModal;
window.closeFeedbackModal = closeFeedbackModal;

/* ==========================================================================
   Interactive Packaging Configurator & Customizer System
   ========================================================================== */

let activeCustomConfig = {
  product: "FIBC Bags",
  dimensions: "90 x 90 x 120 cm",
  gsm: "180 GSM",
  printing: "1-2 Color Flexo",
  liner: "Food-Grade LDPE Liner",
  quantity: "5,000 Bags"
};

function initPackagingConfigurator() {
  const configurator = document.getElementById("customizer");
  if (!configurator) return;

  const productPills = configurator.querySelectorAll(".config-pill[data-field='product']");
  const gsmPills = configurator.querySelectorAll(".config-pill[data-field='gsm']");
  const printPills = configurator.querySelectorAll(".config-pill[data-field='printing']");
  const linerPills = configurator.querySelectorAll(".config-pill[data-field='liner']");

  function setupPillGroup(pills, fieldKey, summaryId) {
    pills.forEach(pill => {
      pill.addEventListener("click", () => {
        pills.forEach(p => p.classList.remove("active"));
        pill.classList.add("active");
        const val = pill.getAttribute("data-val");
        activeCustomConfig[fieldKey] = val;
        const sumEl = document.getElementById(summaryId);
        if (sumEl) sumEl.textContent = val;
      });
    });
  }

  setupPillGroup(productPills, "product", "sumProduct");
  setupPillGroup(gsmPills, "gsm", "sumGSM");
  setupPillGroup(printPills, "printing", "sumPrinting");
  setupPillGroup(linerPills, "liner", "sumLiner");

  const dimWidth = document.getElementById("customWidth");
  const dimLength = document.getElementById("customLength");
  const dimUnit = document.getElementById("customUnit");
  const sumDimensions = document.getElementById("sumDimensions");

  function updateDimensions() {
    const w = (dimWidth && dimWidth.value) ? dimWidth.value.trim() : "24";
    const l = (dimLength && dimLength.value) ? dimLength.value.trim() : "38";
    const u = (dimUnit && dimUnit.value) ? dimUnit.value : "inch";
    const str = `${w} x ${l} ${u}`;
    activeCustomConfig.dimensions = str;
    if (sumDimensions) sumDimensions.textContent = str;
  }

  if (dimWidth) dimWidth.addEventListener("input", updateDimensions);
  if (dimLength) dimLength.addEventListener("input", updateDimensions);
  if (dimUnit) dimUnit.addEventListener("change", updateDimensions);

  const qtyInput = document.getElementById("customQuantity");
  const sumQty = document.getElementById("sumQuantity");
  if (qtyInput) {
    qtyInput.addEventListener("input", () => {
      const q = qtyInput.value ? `${Number(qtyInput.value).toLocaleString()} Bags` : "Custom Requirement";
      activeCustomConfig.quantity = q;
      if (sumQty) sumQty.textContent = q;
    });
  }

  const submitWaBtn = document.getElementById("btnConfigSubmitWA");
  if (submitWaBtn) {
    submitWaBtn.addEventListener("click", (e) => {
      e.preventDefault();
      const waNumber = (typeof COMPANY_INFO !== 'undefined' && COMPANY_INFO.whatsappNumber) ? COMPANY_INFO.whatsappNumber : "919108713258";
      const lines = [
        `*Rayashree Weaving - Bespoke Packaging Custom Order*`,
        ``,
        `📦 *Selected Product Base:* ${activeCustomConfig.product}`,
        `📐 *Custom Dimensions:* ${activeCustomConfig.dimensions}`,
        `⚖️ *Target GSM / Fabric Weight:* ${activeCustomConfig.gsm}`,
        `🎨 *Branding / Printing:* ${activeCustomConfig.printing}`,
        `🛡️ *Liner / Barrier:* ${activeCustomConfig.liner}`,
        `📊 *Order Volume:* ${activeCustomConfig.quantity}`,
        ``,
        `Please confirm raw material availability, minimum manufacturing run, and factory pricing.`
      ];
      window.open(`https://wa.me/${waNumber}?text=${encodeURIComponent(lines.join("\n"))}`, "_blank");
    });
  }

  const submitRfqBtn = document.getElementById("btnConfigSubmitRFQ");
  if (submitRfqBtn) {
    submitRfqBtn.addEventListener("click", (e) => {
      e.preventDefault();
      openCustomizerModal(activeCustomConfig.product);
    });
  }
}

function initCustomizerModal() {
  const modal = document.getElementById("customizerModal");
  if (!modal) return;

  const closeBtns = modal.querySelectorAll(".modal-close-trigger");
  closeBtns.forEach(btn => {
    btn.addEventListener("click", closeCustomizerModal);
  });

  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeCustomizerModal();
  });

  const form = document.getElementById("customizerModalForm");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const clientName = document.getElementById("modalCustName")?.value.trim() || "";
      const phone = document.getElementById("modalCustPhone")?.value.trim() || "";
      const prod = document.getElementById("modalCustProduct")?.value || activeCustomConfig.product;
      const dims = document.getElementById("modalCustDims")?.value.trim() || activeCustomConfig.dimensions;
      const gsm = document.getElementById("modalCustGSM")?.value.trim() || activeCustomConfig.gsm;
      const printing = document.getElementById("modalCustPrinting")?.value || activeCustomConfig.printing;
      const liner = document.getElementById("modalCustLiner")?.value || activeCustomConfig.liner;
      const qty = document.getElementById("modalCustQty")?.value.trim() || activeCustomConfig.quantity;

      if (!clientName || !phone) {
        alert("Please enter your name and phone number.");
        return;
      }

      if (typeof addInquiry === "function") {
        addInquiry({
          clientName: clientName,
          phone: phone,
          product: prod,
          quantity: qty,
          specifications: `Custom Spec: ${dims}, ${gsm}, Printing: ${printing}, Liner: ${liner}`,
          priority: "High"
        });
      }

      closeCustomizerModal();
      form.reset();

      const waNumber = (typeof COMPANY_INFO !== 'undefined' && COMPANY_INFO.whatsappNumber) ? COMPANY_INFO.whatsappNumber : "919108713258";
      const lines = [
        `*Rayashree Weaving - Custom Bag Specification*`,
        ``,
        `📦 *Product:* ${prod}`,
        `📐 *Dimensions:* ${dims}`,
        `⚖️ *GSM Weight:* ${gsm}`,
        `🎨 *Printing:* ${printing}`,
        `🛡️ *Liner Attachment:* ${liner}`,
        `📊 *Quantity:* ${qty}`,
        ``,
        `👤 *Client Details:*`,
        `• *Name:* ${clientName}`,
        `• *Phone:* ${phone}`,
        ``,
        `Please share manufacturing quote and lead time.`
      ];
      window.open(`https://wa.me/${waNumber}?text=${encodeURIComponent(lines.join("\n"))}`, "_blank");
    });
  }
}

function openCustomizerModal(productId = "") {
  const modal = document.getElementById("customizerModal");
  const products = (typeof getProducts === 'function') ? getProducts() : [];
  const prod = products.find(p => p.id === productId || p.slug === productId || p.name === productId);

  if (modal) {
    if (prod) {
      const select = document.getElementById("modalCustProduct");
      if (select) select.value = prod.name;
      const heading = document.getElementById("modalCustHeading");
      if (heading) heading.textContent = `Customize ${prod.name}`;
      const gsmInput = document.getElementById("modalCustGSM");
      if (gsmInput && prod.gsmRange) gsmInput.value = prod.gsmRange;
      const dimsInput = document.getElementById("modalCustDims");
      if (dimsInput && prod.capacityRange) dimsInput.value = prod.capacityRange;
    }
    modal.classList.add("active");
    document.body.style.overflow = "hidden";
    return;
  }

  const section = document.getElementById("customizer");
  if (section) {
    section.scrollIntoView({ behavior: "smooth" });
    return;
  }

  const waNumber = (typeof COMPANY_INFO !== 'undefined' && COMPANY_INFO.whatsappNumber) ? COMPANY_INFO.whatsappNumber : "919108713258";
  const name = prod ? prod.name : productId || "Industrial Bags";
  window.open(`https://wa.me/${waNumber}?text=${encodeURIComponent(`Hello Rayashree, I would like to customize *${name}* with custom dimensions and GSM.`)}`, "_blank");
}

function closeCustomizerModal() {
  const modal = document.getElementById("customizerModal");
  if (modal) {
    modal.classList.remove("active");
    document.body.style.overflow = "";
  }
}

window.openCustomizerModal = openCustomizerModal;
window.closeCustomizerModal = closeCustomizerModal;
window.initPackagingConfigurator = initPackagingConfigurator;
window.initCustomizerModal = initCustomizerModal;






