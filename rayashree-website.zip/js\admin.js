/**
 * Rayashree Weaving Pvt. Ltd. - Admin Portal Script
 * Executive Management, Lead CRM, Product Catalog & Public Pages CMS
 */

function resolveAssetPath(path) {
  if (!path) {
    const isSub = window.location.pathname.includes('/public/') || window.location.pathname.includes('/admin/');
    return isSub ? '../assets/images/bags.jpg' : 'assets/images/bags.jpg';
  }
  if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('data:')) {
    return path;
  }
  const isSub = window.location.pathname.includes('/public/') || window.location.pathname.includes('/admin/');
  if (isSub && !path.startsWith('../') && !path.startsWith('/')) {
    return '../' + path;
  }
  if (!isSub && path.startsWith('../')) {
    return path.replace(/^\.\.\//, '');
  }
  return path;
}

document.addEventListener("DOMContentLoaded", () => {
  initDashboard();
});

let currentFilter = "All";
let searchQuery = "";
let activeInquiryId = null;
let testimonialFilter = "All";
let testimonialSearchQuery = "";

function initDashboard() {
  try { initNavigation(); } catch (e) { console.error("initNavigation error:", e); }
  try { initInquiryModal(); } catch (e) { console.error("initInquiryModal error:", e); }
  try { initExportCSV(); } catch (e) { console.error("initExportCSV error:", e); }
  try { initProductManager(); } catch (e) { console.error("initProductManager error:", e); }
  try { initCmsEditor(); } catch (e) { console.error("initCmsEditor error:", e); }
  try { initCompanyEditor(); } catch (e) { console.error("initCompanyEditor error:", e); }
  try { initLogoUploader(); } catch (e) { console.error("initLogoUploader error:", e); }
  try { initTestimonialManager(); } catch (e) { console.error("initTestimonialManager error:", e); }
  try { renderAll(); } catch (e) { console.error("renderAll error:", e); }
}

/* ==========================================================================
   Tab Navigation Logic
   ========================================================================== */

function initNavigation() {
  const navBtns = document.querySelectorAll(".sidebar-btn[data-view]");
  const viewSections = document.querySelectorAll(".admin-view-section");
  const pageTitle = document.getElementById("adminPageTitle");

  navBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      navBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");

      const viewId = btn.getAttribute("data-view");
      viewSections.forEach(sec => {
        if (sec.id === viewId) {
          sec.style.display = "block";
        } else {
          sec.style.display = "none";
        }
      });

      if (viewId === "viewCompany") {
        renderCompanyProfile();
      }
      if (viewId === "viewTestimonials") {
        renderTestimonialsTable();
      }

      if (pageTitle) {
        const span = btn.querySelector("span");
        if (span) {
          pageTitle.textContent = span.textContent;
        }
      }
    });
  });

  // Search input filter
  const searchInput = document.getElementById("inquirySearch");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      searchQuery = e.target.value.toLowerCase();
      renderInquiriesTable();
    });
  }

  // Filter status pills
  const filterPills = document.querySelectorAll(".status-filter-pill");
  filterPills.forEach(pill => {
    pill.addEventListener("click", () => {
      filterPills.forEach(p => p.classList.remove("active"));
      pill.classList.add("active");
      currentFilter = pill.getAttribute("data-status");
      renderInquiriesTable();
    });
  });
}

function renderAll() {
  renderMetrics();
  renderInquiriesTable();
  renderProductsTable();
  renderCompanyProfile();
  loadCmsFormValues();
  renderTrafficAnalytics();
  renderOperationalAnalytics();
  renderTestimonialsTable();
}


/* ==========================================================================
   Metrics & Traffic Rendering
   ========================================================================== */

function renderMetrics() {
  const inquiries = getInquiries();
  const traffic = typeof getViewAnalytics === "function" ? getViewAnalytics() : { totalViews: 0, todayViews: 0, uniqueVisitors: 0 };
  
  const totalCount = inquiries.length;
  const newCount = inquiries.filter(i => i.status === "New").length;
  const quotedCount = inquiries.filter(i => i.status === "Quoted").length;
  const closedCount = inquiries.filter(i => i.status === "Order Placed").length;

  const elTotal = document.getElementById("metricTotalInquiries");
  const elNew = document.getElementById("metricNewInquiries");
  const elQuoted = document.getElementById("metricQuoted");
  const elClosed = document.getElementById("metricClosed");
  const elPublicViews = document.getElementById("metricPublicViews");
  const elTodayViews = document.getElementById("metricTodayViews");

  if (elTotal) elTotal.textContent = totalCount;
  if (elNew) elNew.textContent = newCount;
  if (elQuoted) elQuoted.textContent = quotedCount;
  if (elClosed) elClosed.textContent = closedCount;
  if (elPublicViews) elPublicViews.textContent = Number(traffic.totalViews || 0).toLocaleString();
  if (elTodayViews) elTodayViews.textContent = Number(traffic.todayViews || 0).toLocaleString();
}

function renderTrafficAnalytics() {
  if (typeof getViewAnalytics !== "function") return;

  const traffic = getViewAnalytics();

  const statTotal = document.getElementById("statTrafficTotal");
  const statToday = document.getElementById("statTrafficToday");
  const statUnique = document.getElementById("statTrafficUnique");

  if (statTotal) statTotal.textContent = Number(traffic.totalViews || 0).toLocaleString();
  if (statToday) statToday.textContent = Number(traffic.todayViews || 0).toLocaleString();
  if (statUnique) statUnique.textContent = Number(traffic.uniqueVisitors || 0).toLocaleString();

  // Render Page Breakdown Progress Bars
  const breakdownContainer = document.getElementById("trafficBreakdownList");
  if (breakdownContainer) {
    breakdownContainer.innerHTML = "";
    const entries = traffic.pageBreakdown ? Object.entries(traffic.pageBreakdown) : [];
    
    if (entries.length === 0 || traffic.totalViews === 0) {
      breakdownContainer.innerHTML = `
        <div style="padding: 2rem 1rem; text-align: center; color: #64748b; background: #f8fafc; border-radius: 8px;">
          <i class="fa-solid fa-chart-line text-gold" style="font-size: 1.75rem; margin-bottom: 0.5rem; display: block;"></i>
          <div style="font-weight: 700; color: #032b27; margin-bottom: 0.25rem;">Live Traffic Tracking Ready</div>
          <div style="font-size: 0.8rem;">Pageview breakdown by URL will record automatically as visitors browse the website.</div>
        </div>
      `;
    } else {
      const maxVal = Math.max(...entries.map(e => e[1]), 1);
      entries.forEach(([pageName, count], idx) => {
        const pct = Math.round((count / (traffic.totalViews || 1)) * 100);
        const barWidth = Math.max(Math.round((count / maxVal) * 100), 5);
        
        const colors = ["#07524a", "#b5832a", "#2563eb", "#10b981", "#7c3aed", "#d97706", "#0284c7", "#059669"];
        const barColor = colors[idx % colors.length];

        const item = document.createElement("div");
        item.innerHTML = `
          <div style="display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.25rem;">
            <span style="color: #032b27;"><i class="fa-solid fa-file-lines" style="color: ${barColor}; margin-right: 0.35rem;"></i> ${pageName}</span>
            <strong style="color: #0f172a;">${count.toLocaleString()} views (${pct}%)</strong>
          </div>
          <div style="height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden;">
            <div style="width: ${barWidth}%; height: 100%; background: ${barColor}; border-radius: 4px; transition: width 0.4s ease;"></div>
          </div>
        `;
        breakdownContainer.appendChild(item);
      });
    }
  }

  // Render Recent Visitors Stream
  const streamContainer = document.getElementById("trafficRecentStream");
  if (streamContainer) {
    streamContainer.innerHTML = "";
    if (!traffic.recentVisitors || traffic.recentVisitors.length === 0) {
      streamContainer.innerHTML = `
        <div style="padding: 1.5rem 1rem; text-align: center; color: #64748b; font-size: 0.8rem;">
          <i class="fa-solid fa-signal" style="color: #10b981; margin-right: 0.35rem;"></i> Active. Ready to log incoming visitors.
        </div>
      `;
    } else {
      traffic.recentVisitors.forEach(v => {
        const row = document.createElement("div");
        row.style.paddingBottom = "0.5rem";
        row.style.borderBottom = "1px solid #e2e8f0";
        row.innerHTML = `
          <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 700; color: #07524a;">
            <span>${v.page}</span>
            <span style="color: #64748b; font-weight: normal; font-size: 0.725rem;">${v.time}</span>
          </div>
          <div style="font-size: 0.75rem; color: #64748b; display: flex; justify-content: space-between; margin-top: 2px;">
            <span><i class="fa-solid fa-location-dot" style="color: #dfb774;"></i> ${v.location || 'India'}</span>
            <span style="color: #2563eb;">${v.source || 'Direct'}</span>
          </div>
        `;
        streamContainer.appendChild(row);
      });
    }
  }
}

function renderOperationalAnalytics() {
  const inquiries = getInquiries();
  const content = getSiteContent();
  const totalCount = inquiries.length;
  const reviewCount = inquiries.filter(i => i.status === "Under Review").length;
  const quotedCount = inquiries.filter(i => i.status === "Quoted").length;
  const closedCount = inquiries.filter(i => i.status === "Order Placed").length;

  // 1. Conversion Funnel Real Data
  const elIngestedVal = document.getElementById("funnelIngestedVal");
  const elIngestedSub = document.getElementById("funnelIngestedSub");
  const elReviewVal = document.getElementById("funnelReviewVal");
  const elReviewSub = document.getElementById("funnelReviewSub");
  const elQuotedVal = document.getElementById("funnelQuotedVal");
  const elQuotedSub = document.getElementById("funnelQuotedSub");
  const elClosedVal = document.getElementById("funnelClosedVal");
  const elClosedSub = document.getElementById("funnelClosedSub");

  if (elIngestedVal) elIngestedVal.textContent = totalCount;
  if (elIngestedSub) elIngestedSub.textContent = totalCount > 0 ? "100% Inquiries Logged" : "0 Received Yet";

  const reviewPct = totalCount > 0 ? Math.round((reviewCount / totalCount) * 100) : 0;
  if (elReviewVal) elReviewVal.textContent = reviewCount;
  if (elReviewSub) elReviewSub.textContent = totalCount > 0 ? `${reviewPct}% In Review` : "GSM & Sizing Check";

  const quotedPct = totalCount > 0 ? Math.round((quotedCount / totalCount) * 100) : 0;
  if (elQuotedVal) elQuotedVal.textContent = quotedCount;
  if (elQuotedSub) elQuotedSub.textContent = totalCount > 0 ? `${quotedPct}% Quotes Dispatched` : "Pricing Dispatched";

  const closedPct = totalCount > 0 ? Math.round((closedCount / totalCount) * 100) : 0;
  if (elClosedVal) elClosedVal.textContent = closedCount;
  if (elClosedSub) elClosedSub.textContent = totalCount > 0 ? `${closedPct}% In Production` : "Production Scheduled";

  // 2. Real Product Demand Distribution
  const demandContainer = document.getElementById("productDemandDistribution");
  if (demandContainer) {
    demandContainer.innerHTML = "";
    if (totalCount === 0) {
      demandContainer.innerHTML = `
        <div style="text-align: center; padding: 2rem 1rem; color: #64748b;">
          <i class="fa-solid fa-chart-pie" style="font-size: 2rem; color: #dfb774; margin-bottom: 0.5rem; display: block;"></i>
          <div style="font-weight: 700; color: #032b27; margin-bottom: 0.25rem;">No Inquiries Recorded Yet</div>
          <div style="font-size: 0.8rem;">Real customer inquiry demand by product line will automatically chart here as RFQs arrive.</div>
        </div>
      `;
    } else {
      const productCounts = {};
      inquiries.forEach(i => {
        const prod = i.product || "General Packaging";
        productCounts[prod] = (productCounts[prod] || 0) + 1;
      });

      const entries = Object.entries(productCounts).sort((a, b) => b[1] - a[1]);
      const colors = [
        "linear-gradient(90deg, #07524a, #0d8a7d)",
        "linear-gradient(90deg, #b5832a, #dfb774)",
        "linear-gradient(90deg, #2563eb, #60a5fa)",
        "linear-gradient(90deg, #10b981, #34d399)",
        "linear-gradient(90deg, #7c3aed, #a78bfa)"
      ];

      entries.forEach(([prodName, count], idx) => {
        const pct = Math.round((count / totalCount) * 100);
        const color = colors[idx % colors.length];

        const item = document.createElement("div");
        item.innerHTML = `
          <div style="display: flex; justify-content: space-between; font-size: 0.875rem; font-weight: 600; margin-bottom: 0.35rem;">
            <span style="color: #032b27;"><i class="fa-solid fa-box text-gold" style="margin-right: 0.35rem;"></i> ${prodName}</span>
            <strong style="color: #032b27;">${count} RFQ (${pct}%)</strong>
          </div>
          <div style="height: 10px; background: #e2e8f0; border-radius: 5px; overflow: hidden;">
            <div style="width: ${pct}%; height: 100%; background: ${color}; transition: width 0.4s ease;"></div>
          </div>
        `;
        demandContainer.appendChild(item);
      });
    }
  }

  // 3. Dynamic Plant Operations & Capacity from CMS
  if (content && content.infrastructure) {
    const elLooms = document.getElementById("opsLoomsCount");
    const elExtrusion = document.getElementById("opsExtrusion");
    const elOutput = document.getElementById("opsMonthlyOutput");
    const elQuality = document.getElementById("opsQualityCompliance");

    if (elLooms && content.infrastructure.loomsCount) elLooms.textContent = content.infrastructure.loomsCount;
    if (elExtrusion && content.infrastructure.extrusionCapacity) elExtrusion.textContent = content.infrastructure.extrusionCapacity;
    if (elOutput && content.home && content.home.stat1Val) elOutput.textContent = `${content.home.stat1Val} / Month`;
    if (elQuality) elQuality.innerHTML = `<i class="fa-solid fa-check"></i> ${content.infrastructure.qualityStandards || "ISO 9001:2015"}`;
  }
}

/* ==========================================================================
   Inquiries Table Rendering
   ========================================================================== */

function renderInquiriesTable() {
  const tbody = document.getElementById("inquiriesTableBody");
  if (!tbody) return;

  const inquiries = getInquiries();
  tbody.innerHTML = "";

  const filtered = inquiries.filter(item => {
    const matchesStatus = currentFilter === "All" || item.status === currentFilter;
    const matchesSearch = !searchQuery || 
      item.clientName.toLowerCase().includes(searchQuery) ||
      item.product.toLowerCase().includes(searchQuery) ||
      item.phone.toLowerCase().includes(searchQuery) ||
      item.id.toLowerCase().includes(searchQuery);
    return matchesStatus && matchesSearch;
  });

  if (inquiries.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" style="text-align: center; padding: 3.5rem 2rem;">
          <div style="font-size: 2.75rem; color: #dfb774; margin-bottom: 0.75rem;"><i class="fa-solid fa-inbox"></i></div>
          <h4 style="font-size: 1.15rem; color: #032b27; font-weight: 800; margin-bottom: 0.35rem;">No Customer Inquiries Yet</h4>
          <p style="color: #64748b; font-size: 0.875rem; max-width: 500px; margin: 0 auto 1.25rem;">
            Real customer quote requests and RFQs submitted on the website or via WhatsApp will automatically appear here in real-time.
          </p>
          <div style="display: flex; gap: 0.75rem; justify-content: center; flex-wrap: wrap;">
            <a href="../index.html" target="_blank" class="btn btn-outline btn-sm">
              <i class="fa-solid fa-arrow-up-right-from-square"></i> Test Quote Form on Public Site
            </a>
            <button onclick="generateDemoInquiries()" class="btn btn-gold btn-sm" style="font-weight: 700;">
              <i class="fa-solid fa-bolt"></i> Load Sample Demo Leads
            </button>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 2.5rem; color: #64748b;">No inquiries found matching current filters.</td></tr>`;
    return;
  }

  filtered.forEach(item => {
    const tr = document.createElement("tr");
    
    let badgeClass = "badge-new";
    if (item.status === "Under Review") badgeClass = "badge-under-review";
    else if (item.status === "Quoted") badgeClass = "badge-quoted";
    else if (item.status === "Order Placed") badgeClass = "badge-order-placed";
    else if (item.status === "Archived") badgeClass = "badge-archived";

    const cleanPhone = item.phone.replace(/[^0-9]/g, "");
    const waText = encodeURIComponent(`Hello ${item.clientName}, This is Rayashree from Rayashree Weaving regarding your inquiry #${item.id} for ${item.product}.`);

    tr.innerHTML = `
      <td><strong>${item.id}</strong><div style="font-size: 0.75rem; color: #94a3b8;">${item.date}</div></td>
      <td>
        <div style="font-weight: 700; color: #032b27;">${item.clientName}</div>
        <div style="font-size: 0.8rem; color: #64748b;">${item.contactPerson || ""}</div>
      </td>
      <td>
        <div style="font-weight: 600;">${item.product}</div>
        <div style="font-size: 0.8rem; color: #07524a; font-weight: 700;">Qty: ${item.quantity}</div>
      </td>
      <td style="max-width: 250px; font-size: 0.825rem; color: #475569;">
        ${item.specifications}
        ${item.notes ? `<div style="font-style: italic; color: #b45309; margin-top: 4px;">Note: ${item.notes}</div>` : ""}
      </td>
      <td>
        <div style="font-size: 0.85rem;"><a href="tel:${cleanPhone}" style="color: #0d8a7d; font-weight: 600;"><i class="fa-solid fa-phone"></i> ${item.phone}</a></div>
        <div style="font-size: 0.775rem; color: #64748b;">${item.email}</div>
      </td>
      <td><span class="badge ${badgeClass}">${item.status}</span></td>
      <td>
        <div class="action-btns">
          <button class="btn-icon" title="Copy Inquiry Details" onclick="copyInquiryDetails('${item.id}')">
            <i class="fa-solid fa-copy"></i>
          </button>
          <button class="btn-icon" title="Edit Status / Notes" onclick="openStatusModal('${item.id}')">
            <i class="fa-solid fa-pen-to-square"></i>
          </button>
          <a href="https://wa.me/${cleanPhone}?text=${waText}" target="_blank" class="btn-icon btn-whatsapp" title="WhatsApp Client">
            <i class="fa-brands fa-whatsapp"></i>
          </a>
          <button class="btn-icon" title="Delete Inquiry" onclick="deleteInquiryRow('${item.id}')" style="color: #ef4444;">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

/* ==========================================================================
   Status Modal & Actions
   ========================================================================== */

function initInquiryModal() {
  const modal = document.getElementById("statusModal");
  if (!modal) return;

  const form = document.getElementById("statusForm");

  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (!activeInquiryId) return;

      const newStatus = document.getElementById("modalStatusSelect").value;
      const newNotes = document.getElementById("modalNotesText").value.trim();

      updateInquiryStatus(activeInquiryId, newStatus, newNotes);
      closeStatusModal();
      renderAll();
    });
  }
}

function openStatusModal(inquiryId) {
  activeInquiryId = inquiryId;
  const modal = document.getElementById("statusModal");
  const inquiries = getInquiries();
  const inquiry = inquiries.find(i => i.id === inquiryId);

  if (!modal || !inquiry) return;

  document.getElementById("modalInquiryTitle").textContent = `Update ${inquiry.id} (${inquiry.clientName})`;
  document.getElementById("modalStatusSelect").value = inquiry.status;
  document.getElementById("modalNotesText").value = inquiry.notes || "";

  modal.classList.add("active");
}

function closeStatusModal() {
  const modal = document.getElementById("statusModal");
  if (modal) modal.classList.remove("active");
}

function deleteInquiryRow(inquiryId) {
  if (confirm(`Are you sure you want to delete inquiry ${inquiryId}?`)) {
    let inquiries = getInquiries();
    inquiries = inquiries.filter(i => i.id !== inquiryId);
    saveInquiries(inquiries);
    renderAll();
  }
}

function generateDemoInquiries() {
  const sampleLeads = [
    {
      id: "RFQ-9012",
      date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      clientName: "Karnataka Agri Feeds Ltd.",
      contactPerson: "Ramesh Kumar (Purchase Mgr)",
      product: "50kg Cattle Feed PP Woven Sacks",
      quantity: "25,000 Sacks",
      specifications: "110 GSM, 800 Denier, BOPP Laminated, 100% Virgin Polymer",
      phone: "+91 9845012345",
      email: "procurement@karnatakaagrifeeds.com",
      status: "New",
      notes: "High priority bulk order request for upcoming harvest season."
    },
    {
      id: "RFQ-9013",
      date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      clientName: "Deccan Cement & Infrastructure",
      contactPerson: "Siddharth Rao (Plant Head)",
      product: "Block Bottom Valve Cement Bags",
      quantity: "50,000 Sacks",
      specifications: "75 GSM micro-perforated, zero-dust leakage, 2-color flexo print",
      phone: "+91 9900112233",
      email: "siddharth@deccancement.in",
      status: "Under Review",
      notes: "Sent technical GSM sample swatches for drop test verification."
    },
    {
      id: "RFQ-9014",
      date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      clientName: "Malnad Coffee Exports Pvt. Ltd.",
      contactPerson: "Anita Deshmukh (Logistics Director)",
      product: "1000kg FIBC Jumbo Bags (Type A)",
      quantity: "2,500 Jumbo Bags",
      specifications: "180 GSM UV Stabilized, Top Spout, Bottom Discharge, SWL 1250kg",
      phone: "+91 9741234567",
      email: "exports@malnadcoffee.com",
      status: "Quoted",
      notes: "Official commercial quote dispatched via WhatsApp and Email."
    }
  ];

  localStorage.setItem("rw_inquiries", JSON.stringify(sampleLeads));
  renderAll();
}

/* ==========================================================================
   Export CSV
   ========================================================================== */

function initExportCSV() {
  const exportBtn = document.getElementById("exportCsvBtn");
  if (!exportBtn) return;

  exportBtn.addEventListener("click", () => {
    const inquiries = getInquiries();
    if (inquiries.length === 0) {
      alert("No inquiry records to export.");
      return;
    }

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Inquiry ID,Date,Client Name,Contact Person,Phone,Email,Product,Quantity,Specifications,Status,Priority,Notes\n";

    inquiries.forEach(row => {
      const escape = (str) => `"${(str || "").toString().replace(/"/g, '""')}"`;
      csvContent += [
        escape(row.id),
        escape(row.date),
        escape(row.clientName),
        escape(row.contactPerson),
        escape(row.phone),
        escape(row.email),
        escape(row.product),
        escape(row.quantity),
        escape(row.specifications),
        escape(row.status),
        escape(row.priority),
        escape(row.notes)
      ].join(",") + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Rayashree_Inquiries_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });
}

/* ==========================================================================
   Product Manager Logic (Image Upload, Auto Canvas Compression, Live Sync)
   ========================================================================== */

function compressImageFile(file, maxWidth = 800, maxHeight = 600, quality = 0.82) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width / height > maxWidth / maxHeight) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL("image/jpeg", quality);
        resolve(dataUrl);
      };
      img.onerror = () => resolve(e.target.result);
      img.src = e.target.result;
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

function initProductManager() {
  const addProductBtn = document.getElementById("addNewProductBtn");
  const productModal = document.getElementById("productEditModal");
  const productForm = document.getElementById("productEditForm");
  const previewImg = document.getElementById("prodImagePreview");
  const imageUrlInput = document.getElementById("prodFormImageUrl");
  const imageFileInput = document.getElementById("prodFormImageFile");
  const dropZone = document.getElementById("prodImageDropzone");
  const categoryInput = document.getElementById("prodFormCategory");

  // Live Card Preview Elements
  const liveCardTitle = document.getElementById("livePreviewTitle");
  const liveCardBadge = document.getElementById("livePreviewBadge");
  const liveCardCategory = document.getElementById("livePreviewCategory");
  const liveCardCapacity = document.getElementById("livePreviewCapacity");
  const liveCardGsm = document.getElementById("livePreviewGsm");
  const liveCardImg = document.getElementById("livePreviewImg");

  function updateLivePreview() {
    const name = document.getElementById("prodFormName") ? document.getElementById("prodFormName").value.trim() : "";
    const badge = document.getElementById("prodFormBadge") ? document.getElementById("prodFormBadge").value.trim() : "";
    const cat = categoryInput ? categoryInput.value.trim() : "";
    const cap = document.getElementById("prodFormCapacity") ? document.getElementById("prodFormCapacity").value.trim() : "";
    const gsm = document.getElementById("prodFormGsm") ? document.getElementById("prodFormGsm").value.trim() : "";
    const img = (imageUrlInput && imageUrlInput.value.trim()) ? imageUrlInput.value.trim() : "assets/images/bags.jpg";

    if (liveCardTitle) liveCardTitle.textContent = name || "Product Title Preview";
    if (liveCardBadge) liveCardBadge.textContent = badge || name || "New Bag";
    if (liveCardCategory) liveCardCategory.textContent = cat || "Category";
    if (liveCardCapacity) liveCardCapacity.textContent = cap || "25 kg / 50 kg";
    if (liveCardGsm) liveCardGsm.textContent = gsm || "70 - 120 GSM";
    if (liveCardImg) liveCardImg.src = resolveAssetPath(img);
    if (previewImg) previewImg.src = resolveAssetPath(img);
  }

  // Bind live preview listeners
  const formInputs = ["prodFormName", "prodFormBadge", "prodFormCategory", "prodFormCapacity", "prodFormGsm", "prodFormTagline"];
  formInputs.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("input", updateLivePreview);
  });

  // URL Input
  if (imageUrlInput) {
    imageUrlInput.addEventListener("input", (e) => {
      const val = e.target.value.trim();
      if (val) {
        if (previewImg) previewImg.src = val;
        updateLivePreview();
      }
    });
  }

  // Drag and drop & File Upload with Canvas Compression
  async function handleFile(file) {
    if (!file || !file.type.startsWith("image/")) {
      alert("Please upload a valid image file (JPG, PNG, WebP).");
      return;
    }
    try {
      if (previewImg) previewImg.style.opacity = "0.5";
      const compressedDataUrl = await compressImageFile(file, 800, 600, 0.82);
      if (previewImg) {
        previewImg.src = compressedDataUrl;
        previewImg.style.opacity = "1";
      }
      if (imageUrlInput) imageUrlInput.value = compressedDataUrl;
      updateLivePreview();
    } catch (err) {
      console.error("Image compression error:", err);
      if (previewImg) previewImg.style.opacity = "1";
    }
  }

  if (imageFileInput) {
    imageFileInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) handleFile(file);
    });
  }

  if (dropZone) {
    ['dragenter', 'dragover'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.style.borderColor = "#b5832a";
        dropZone.style.background = "#fef9ee";
      }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.style.borderColor = "#cbd5e1";
        dropZone.style.background = "#f8fafc";
      }, false);
    });

    dropZone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const file = dt.files[0];
      if (file) handleFile(file);
    });
  }

  if (imageUrlInput) {
    imageUrlInput.addEventListener("input", () => {
      const val = imageUrlInput.value.trim();
      if (val) {
        if (previewImg) previewImg.src = val;
        if (liveCardImg) liveCardImg.src = val;
      }
    });
  }

  const pSearch = document.getElementById("adminProductSearch");
  const pCatFilter = document.getElementById("adminProductCategoryFilter");
  if (pSearch) {
    pSearch.addEventListener("input", renderProductsTable);
  }
  if (pCatFilter) {
    pCatFilter.addEventListener("change", renderProductsTable);
  }

  if (addProductBtn && productModal) {
    addProductBtn.addEventListener("click", () => {
      document.getElementById("productModalTitle").textContent = "Add New Manufacturing Product / Bag Line";
      document.getElementById("prodFormId").value = "";
      document.getElementById("prodFormName").value = "";
      document.getElementById("prodFormBadge").value = "";
      if (categoryInput) categoryInput.value = "";
      document.getElementById("prodFormGsm").value = "";
      document.getElementById("prodFormCapacity").value = "";
      document.getElementById("prodFormMaterial").value = "";
      document.getElementById("prodFormTagline").value = "";
      if (document.getElementById("prodFormFeatures")) {
        document.getElementById("prodFormFeatures").value = "";
      }
      if (document.getElementById("prodFormSpecs")) {
        document.getElementById("prodFormSpecs").value = "";
      }
      
      const defaultImg = "assets/images/bags.jpg";
      if (previewImg) previewImg.src = resolveAssetPath(defaultImg);
      if (imageUrlInput) imageUrlInput.value = "";
      
      updateLivePreview();
      productModal.classList.add("active");
    });
  }

  if (productForm && productModal) {
    productForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const products = getProducts();
      const existingId = document.getElementById("prodFormId").value;
      const name = document.getElementById("prodFormName").value.trim();
      const badge = document.getElementById("prodFormBadge").value.trim() || name;
      const category = categoryInput ? categoryInput.value.trim() || "Industrial Packaging" : "Industrial Packaging";

      const gsm = document.getElementById("prodFormGsm").value.trim() || "65 - 120 GSM";
      const capacity = document.getElementById("prodFormCapacity").value.trim() || "50 kg";
      const material = document.getElementById("prodFormMaterial").value.trim() || "100% Virgin Polypropylene (PP)";
      const tagline = document.getElementById("prodFormTagline").value.trim() || "Heavy-Duty Precision Woven Packaging Solution.";
      const image = (imageUrlInput && imageUrlInput.value.trim()) ? imageUrlInput.value.trim() : "assets/images/bags.jpg";

      // Parse features
      const featuresRaw = document.getElementById("prodFormFeatures") ? document.getElementById("prodFormFeatures").value : "";
      const features = featuresRaw
        ? featuresRaw.split("\n").map(f => f.replace(/^[-*•]\s*/, '').trim()).filter(Boolean)
        : ["Custom high tensile extrusion", "Engineered for heavy logistics", "Food-grade & industrial certified"];

      // Parse specs
      const specsRaw = document.getElementById("prodFormSpecs") ? document.getElementById("prodFormSpecs").value : "";
      const specifications = {
        "Standard Sizes": capacity,
        "GSM Weight": gsm,
        "Material": material
      };
      if (specsRaw) {
        specsRaw.split("\n").forEach(line => {
          const parts = line.split(/:(.+)/);
          if (parts.length >= 2 && parts[0].trim()) {
            specifications[parts[0].trim()] = parts[1].trim();
          }
        });
      }

      if (existingId) {
        const idx = products.findIndex(p => p.id === existingId || p.slug === existingId);
        if (idx !== -1) {
          products[idx].name = name;
          products[idx].shortName = badge;
          products[idx].badge = badge;
          products[idx].category = category;
          products[idx].gsmRange = gsm;
          products[idx].capacityRange = capacity;
          products[idx].material = material;
          products[idx].tagline = tagline;
          products[idx].image = image;
          products[idx].features = features;
          products[idx].specifications = specifications;
        }
      } else {
        const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-") + "-" + Math.floor(100 + Math.random() * 900);
        products.push({
          id: slug,
          slug: slug,
          name: name,
          shortName: badge,
          badge: badge,
          category: category,
          gsmRange: gsm,
          capacityRange: capacity,
          material: material,
          tagline: tagline,
          image: image,
          features: features,
          specifications: specifications,
          applications: ["Industrial Logistics", "Bulk Packaging", "Commercial Distribution"],
          featured: true
        });
      }

      saveProducts(products);
      closeProductModal();
      renderProductsTable();
      showAdminToast(`Product "${name}" published live to public website!`);
    });
  }
}

function closeProductModal() {
  const modal = document.getElementById("productEditModal");
  if (modal) modal.classList.remove("active");
}

function setFormCategory(val) {
  const input = document.getElementById("prodFormCategory");
  if (input) {
    input.value = val;
    input.dispatchEvent(new Event("input"));
  }
}

function setFormCapacity(val) {
  const input = document.getElementById("prodFormCapacity");
  if (input) {
    input.value = val;
    input.dispatchEvent(new Event("input"));
  }
}

function setFormGsm(val) {
  const input = document.getElementById("prodFormGsm");
  if (input) {
    input.value = val;
    input.dispatchEvent(new Event("input"));
  }
}

function renderProductsTable() {
  const tbody = document.getElementById("productsTableBody");
  if (!tbody) return;

  const searchInput = document.getElementById("adminProductSearch");
  const catFilter = document.getElementById("adminProductCategoryFilter");
  const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
  const selectedCat = catFilter ? catFilter.value : "All";

  const allProducts = getProducts();

  // Dynamically populate category dropdown with all categories currently in products
  if (catFilter) {
    const currentVal = catFilter.value;
    const categories = Array.from(new Set(allProducts.map(p => p.category).filter(Boolean))).sort();
    
    catFilter.innerHTML = `<option value="All">All Categories (${allProducts.length})</option>`;
    categories.forEach(cat => {
      const count = allProducts.filter(p => p.category === cat).length;
      const opt = document.createElement("option");
      opt.value = cat;
      opt.textContent = `${cat} (${count})`;
      if (cat === currentVal) opt.selected = true;
      catFilter.appendChild(opt);
    });

    if (currentVal && (currentVal === "All" || categories.includes(currentVal))) {
      catFilter.value = currentVal;
    } else {
      catFilter.value = "All";
    }
  }

  let products = allProducts;
  if (catFilter && catFilter.value !== "All") {
    products = products.filter(p => p.category === catFilter.value);
  }
  if (query) {
    products = products.filter(p => 
      (p.name && p.name.toLowerCase().includes(query)) ||
      (p.category && p.category.toLowerCase().includes(query)) ||
      (p.gsmRange && p.gsmRange.toLowerCase().includes(query)) ||
      (p.tagline && p.tagline.toLowerCase().includes(query))
    );
  }

  if (allProducts.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" style="text-align: center; padding: 3.5rem 2rem;">
          <div style="font-size: 2.5rem; color: #dfb774; margin-bottom: 0.75rem;"><i class="fa-solid fa-boxes-stacked"></i></div>
          <h4 style="font-size: 1.15rem; color: #032b27; font-weight: 800; margin-bottom: 0.35rem;">No Products in Catalog Yet</h4>
          <p style="color: #64748b; font-size: 0.875rem; margin-bottom: 1.25rem;">Your catalog is currently empty. You can add new custom products from scratch or restore the 7 factory standard product lines.</p>
          <div style="display: flex; gap: 0.75rem; justify-content: center; flex-wrap: wrap;">
            <button class="btn btn-gold btn-sm" onclick="document.getElementById('addNewProductBtn').click()">
              <i class="fa-solid fa-plus"></i> Add New Product Now
            </button>
            <button class="btn btn-outline btn-sm" onclick="restoreStandardProducts()" style="color: #07524a; border-color: #dfb774; background: #fffcf4;">
              <i class="fa-solid fa-rotate-left" style="color: #b5832a;"></i> Restore 7 Factory Lines
            </button>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  if (products.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 2rem; color: #64748b;">No products matched your filter. <button class="btn btn-sm btn-outline" style="margin-left: 0.5rem;" onclick="if(document.getElementById('adminProductSearch')) document.getElementById('adminProductSearch').value=''; if(document.getElementById('adminProductCategoryFilter')) document.getElementById('adminProductCategoryFilter').value='All'; renderProductsTable();">Clear Filters</button></td></tr>`;
    return;
  }

  tbody.innerHTML = "";
  products.forEach((p) => {
    const tr = document.createElement("tr");
    const viewLink = `../public/products.html#products`;

    tr.innerHTML = `
      <td>
        <img src="${resolveAssetPath(p.image)}" alt="${p.name}" style="width: 58px; height: 50px; object-fit: cover; border-radius: 8px; border: 1.5px solid #dfb774; box-shadow: 0 2px 5px rgba(0,0,0,0.08);" onerror="this.src='../assets/images/bags.jpg'">
      </td>
      <td>
        <div style="font-weight: 700; color: #032b27;">${p.name}</div>
        <div style="font-size: 0.775rem; color: #64748b;">${p.tagline || ""}</div>
      </td>
      <td><span class="badge badge-under-review">${p.category}</span></td>
      <td style="font-weight: 600; font-size: 0.85rem;">${p.capacityRange || "50 kg"}</td>
      <td style="font-size: 0.85rem;">${p.gsmRange || "70 - 120 GSM"}</td>
      <td><span class="badge badge-quoted"><i class="fa-solid fa-circle-check"></i> Published Live</span></td>
      <td>
        <div class="action-btns">
          <a href="${viewLink}" class="btn-icon" title="View On Public Website" target="_blank">
            <i class="fa-solid fa-arrow-up-right-from-square"></i>
          </a>
          <button class="btn-icon" title="Duplicate / Clone Product" onclick="cloneProduct('${p.id}')">
            <i class="fa-solid fa-copy"></i>
          </button>
          <button class="btn-icon" title="Edit Product" onclick="editProductRow('${p.id}')">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button class="btn-icon" title="Delete Product" onclick="deleteProductRow('${p.id}')" style="color: #ef4444;">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function cloneProduct(productId) {
  const products = getProducts();
  const prod = products.find(p => p.id === productId || p.slug === productId);
  if (!prod) return;

  editProductRow(productId);
  document.getElementById("prodFormId").value = "";
  document.getElementById("productModalTitle").textContent = `Duplicate: ${prod.name} (Copy)`;
  document.getElementById("prodFormName").value = `${prod.name} (Copy)`;
  document.getElementById("prodFormBadge").value = "New Variation";
  showAdminToast("Product cloned! Adjust specifications and click Save.");
}

function copyInquiryDetails(id) {
  const inquiries = getInquiries();
  const item = inquiries.find(i => i.id === id);
  if (!item) return;

  const text = `Rayashree Inquiry #${item.id}\nClient: ${item.clientName}\nPhone: ${item.phone}\nEmail: ${item.email}\nProduct: ${item.product}\nQuantity: ${item.quantity}\nSpecs: ${item.specifications}\nStatus: ${item.status}`;
  navigator.clipboard.writeText(text).then(() => {
    showAdminToast(`Inquiry #${item.id} copied to clipboard!`);
  }).catch(() => {
    showAdminToast(`Inquiry #${item.id} details copied.`);
  });
}

function showAdminToast(msg) {
  const toast = document.getElementById("adminToast");
  const toastMsg = document.getElementById("adminToastMsg");
  if (!toast || !toastMsg) return;
  toastMsg.textContent = msg;
  toast.classList.add("active");
  setTimeout(() => {
    toast.classList.remove("active");
  }, 3200);
}

function editProductRow(productId) {
  const products = getProducts();
  const prod = products.find(p => p.id === productId || p.slug === productId);
  if (!prod) return;

  const modal = document.getElementById("productEditModal");
  if (!modal) return;

  document.getElementById("productModalTitle").textContent = `Edit Product: ${prod.name}`;
  document.getElementById("prodFormId").value = prod.id;
  document.getElementById("prodFormName").value = prod.name;
  document.getElementById("prodFormBadge").value = prod.badge || prod.shortName || prod.name;
  
  const catInput = document.getElementById("prodFormCategory");
  if (catInput) catInput.value = prod.category || "";

  document.getElementById("prodFormGsm").value = prod.gsmRange || "70 - 120 GSM";
  document.getElementById("prodFormCapacity").value = prod.capacityRange || "50 kg";
  document.getElementById("prodFormMaterial").value = prod.material || "100% Virgin Polymer";
  document.getElementById("prodFormTagline").value = prod.tagline || "";
  
  if (document.getElementById("prodFormFeatures")) {
    document.getElementById("prodFormFeatures").value = Array.isArray(prod.features) ? prod.features.join("\n") : "";
  }
  if (document.getElementById("prodFormSpecs") && prod.specifications) {
    const lines = Object.entries(prod.specifications).map(([k, v]) => `${k}: ${v}`).join("\n");
    document.getElementById("prodFormSpecs").value = lines;
  }

  const imgPath = prod.image || "assets/images/bags.jpg";
  const previewImg = document.getElementById("prodImagePreview");
  const imageUrlInput = document.getElementById("prodFormImageUrl");
  if (previewImg) previewImg.src = resolveAssetPath(imgPath);
  if (imageUrlInput) imageUrlInput.value = imgPath;

  // Update Live preview
  const liveCardTitle = document.getElementById("livePreviewTitle");
  const liveCardBadge = document.getElementById("livePreviewBadge");
  const liveCardCategory = document.getElementById("livePreviewCategory");
  const liveCardCapacity = document.getElementById("livePreviewCapacity");
  const liveCardGsm = document.getElementById("livePreviewGsm");
  const liveCardImg = document.getElementById("livePreviewImg");

  if (liveCardTitle) liveCardTitle.textContent = prod.name;
  if (liveCardBadge) liveCardBadge.textContent = prod.badge || prod.shortName || prod.name;
  if (liveCardCategory) liveCardCategory.textContent = prod.category;
  if (liveCardCapacity) liveCardCapacity.textContent = prod.capacityRange;
  if (liveCardGsm) liveCardGsm.textContent = prod.gsmRange;
  if (liveCardImg) liveCardImg.src = resolveAssetPath(imgPath);

  modal.classList.add("active");
}

function deleteProductRow(productId) {
  if (confirm(`Are you sure you want to remove product "${productId}" from the public catalog?`)) {
    let products = getProducts();
    products = products.filter(p => p.id !== productId && p.slug !== productId);
    saveProducts(products);
    renderProductsTable();
    showAdminToast("Product removed successfully.");
  }
}

function resetDefaultProducts() {
  if (confirm("Are you sure you want to remove all products from the catalog? You can then add new products from scratch.")) {
    saveProducts([]);
    renderProductsTable();
    showAdminToast("All products removed from catalog.");
  }
}

function restoreStandardProducts() {
  if (confirm("Restore the 7 factory standard manufacturing product lines (Cattle Feed, Poultry Feed, Cement Valve Bags, Silage Bags, Jute Sacks, Linen Fabrics, FIBC Jumbo Bags)?")) {
    if (typeof DEFAULT_PRODUCTS !== "undefined") {
      saveProducts(JSON.parse(JSON.stringify(DEFAULT_PRODUCTS)));
      renderProductsTable();
      showAdminToast("7 Factory standard product lines restored successfully!");
    }
  }
}


/* ==========================================================================
   Logo & Branding Uploader Logic
   ========================================================================== */

function initLogoUploader() {
  // CMS Branding Tab Logo
  const cmsLogoFile = document.getElementById("cmsBrandLogoFile");
  const cmsLogoUrl = document.getElementById("cmsBrandLogoUrl");
  const cmsLogoPreview = document.getElementById("cmsBrandLogoPreview");

  // Company Modal Logo
  const compLogoFile = document.getElementById("compEditLogoFile");
  const compLogoUrl = document.getElementById("compEditLogoUrl");
  const compLogoPreview = document.getElementById("compEditLogoPreview");

  async function handleLogoUpload(file, urlInput, previewImg, otherUrlInput, otherPreviewImg) {
    if (!file || !file.type.startsWith("image/")) {
      showAdminToast("Please select a valid image file (PNG, SVG, JPG).");
      return;
    }
    try {
      if (previewImg) previewImg.style.opacity = "0.5";
      const compressed = await compressImageFile(file, 600, 300, 0.9);
      if (previewImg) {
        previewImg.src = compressed;
        previewImg.style.opacity = "1";
      }
      if (urlInput) urlInput.value = compressed;
      if (otherUrlInput) otherUrlInput.value = compressed;
      if (otherPreviewImg) otherPreviewImg.src = compressed;
      showAdminToast("Logo loaded! Click Save to apply across all pages.");
    } catch (e) {
      console.error("Logo upload error:", e);
      if (previewImg) previewImg.style.opacity = "1";
    }
  }

  if (cmsLogoFile) {
    cmsLogoFile.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) handleLogoUpload(file, cmsLogoUrl, cmsLogoPreview, compLogoUrl, compLogoPreview);
    });
  }

  if (cmsLogoUrl) {
    cmsLogoUrl.addEventListener("input", (e) => {
      const val = e.target.value.trim();
      if (val) {
        if (cmsLogoPreview) cmsLogoPreview.src = val;
        if (compLogoUrl) compLogoUrl.value = val;
        if (compLogoPreview) compLogoPreview.src = val;
      }
    });
  }

  if (compLogoFile) {
    compLogoFile.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) handleLogoUpload(file, compLogoUrl, compLogoPreview, cmsLogoUrl, cmsLogoPreview);
    });
  }

  if (compLogoUrl) {
    compLogoUrl.addEventListener("input", (e) => {
      const val = e.target.value.trim();
      if (val) {
        if (compLogoPreview) compLogoPreview.src = val;
        if (cmsLogoUrl) cmsLogoUrl.value = val;
        if (cmsLogoPreview) cmsLogoPreview.src = val;
      }
    });
  }
}

/* ==========================================================================
   Public Pages CMS Editor Logic
   ========================================================================== */

function initCmsEditor() {
  // CMS Tab switching
  const cmsTabs = document.querySelectorAll(".cms-tab-btn");
  const cmsPanels = document.querySelectorAll(".cms-tab-content");

  cmsTabs.forEach(btn => {
    btn.addEventListener("click", () => {
      cmsTabs.forEach(b => {
        b.style.borderBottom = "none";
        b.style.color = "#64748b";
        b.classList.remove("active");
      });
      btn.style.borderBottom = "3px solid #032b27";
      btn.style.color = "#032b27";
      btn.classList.add("active");

      const tabTarget = btn.getAttribute("data-cms-tab");
      cmsPanels.forEach(panel => {
        panel.style.display = panel.id === tabTarget ? "block" : "none";
      });
    });
  });

  loadCmsFormValues();
}

function loadCmsFormValues() {
  const content = getSiteContent();
  const company = getCompanyInfo();

  // 1. Home Page CMS
  if (content && content.home) {
    if (document.getElementById("cmsHomeHeroTag")) document.getElementById("cmsHomeHeroTag").value = content.home.heroTag || "";
    if (document.getElementById("cmsHomeHeroTitle")) document.getElementById("cmsHomeHeroTitle").value = content.home.heroTitle || "";
    if (document.getElementById("cmsHomeHeroSubtitle")) document.getElementById("cmsHomeHeroSubtitle").value = content.home.heroSubtitle || "";
    if (document.getElementById("cmsHomeStat1Val")) document.getElementById("cmsHomeStat1Val").value = content.home.stat1Val || "";
    if (document.getElementById("cmsHomeStat1Label")) document.getElementById("cmsHomeStat1Label").value = content.home.stat1Label || "";
    if (document.getElementById("cmsHomeStat2Val")) document.getElementById("cmsHomeStat2Val").value = content.home.stat2Val || "";
    if (document.getElementById("cmsHomeStat2Label")) document.getElementById("cmsHomeStat2Label").value = content.home.stat2Label || "";
    if (document.getElementById("cmsHomeStat3Val")) document.getElementById("cmsHomeStat3Val").value = content.home.stat3Val || "";
    if (document.getElementById("cmsHomeStat3Label")) document.getElementById("cmsHomeStat3Label").value = content.home.stat3Label || "";
    if (document.getElementById("cmsHomeStat4Val")) document.getElementById("cmsHomeStat4Val").value = content.home.stat4Val || "";
    if (document.getElementById("cmsHomeStat4Label")) document.getElementById("cmsHomeStat4Label").value = content.home.stat4Label || "";
  }

  // 2. Products Page CMS
  if (content && content.products) {
    if (document.getElementById("cmsProductsHeroTitle")) document.getElementById("cmsProductsHeroTitle").value = content.products.heroTitle || "Complete Manufacturing Portfolio";
    if (document.getElementById("cmsProductsHeroSubtitle")) document.getElementById("cmsProductsHeroSubtitle").value = content.products.heroSubtitle || "";
    if (document.getElementById("cmsProductsCustomTitle")) document.getElementById("cmsProductsCustomTitle").value = content.products.customTitle || "Need Bespoke Sizing, GSM or Liner Fit?";
    if (document.getElementById("cmsProductsCustomDesc")) document.getElementById("cmsProductsCustomDesc").value = content.products.customDesc || "";
  }

  // 3. About Us CMS
  if (content && content.about) {
    if (document.getElementById("cmsAboutHeading")) document.getElementById("cmsAboutHeading").value = content.about.heading || "";
    if (document.getElementById("cmsAboutSubheading")) document.getElementById("cmsAboutSubheading").value = content.about.subheading || "";
    if (document.getElementById("cmsAboutCeoMessage")) document.getElementById("cmsAboutCeoMessage").value = content.about.ceoMessage || "";
    if (document.getElementById("cmsAboutCoreVision")) document.getElementById("cmsAboutCoreVision").value = content.about.coreVision || "";
  }

  // 4. Infrastructure CMS
  if (content && content.infrastructure) {
    if (document.getElementById("cmsInfraHeading")) document.getElementById("cmsInfraHeading").value = content.infrastructure.heading || "";
    if (document.getElementById("cmsInfraSubheading")) document.getElementById("cmsInfraSubheading").value = content.infrastructure.subheading || "";
    if (document.getElementById("cmsInfraLoomsCount")) document.getElementById("cmsInfraLoomsCount").value = content.infrastructure.loomsCount || "";
    if (document.getElementById("cmsInfraExtrusion")) document.getElementById("cmsInfraExtrusion").value = content.infrastructure.extrusionCapacity || "";
    if (document.getElementById("cmsInfraPrinting")) document.getElementById("cmsInfraPrinting").value = content.infrastructure.printingTech || "";
    if (document.getElementById("cmsInfraQuality")) document.getElementById("cmsInfraQuality").value = content.infrastructure.qualityStandards || "";
  }

  // 5. Contact & Footer CMS
  if (company) {
    if (document.getElementById("cmsContactCeoName")) document.getElementById("cmsContactCeoName").value = company.ceo || "Rayashree";
    if (document.getElementById("cmsContactPhone")) document.getElementById("cmsContactPhone").value = company.phone || "+91 9108713258";
    if (document.getElementById("cmsContactEmail")) document.getElementById("cmsContactEmail").value = company.email || "rayashreewpvtltd@gmail.com";
    if (document.getElementById("cmsContactHours")) document.getElementById("cmsContactHours").value = company.hours || "Mon - Sat: 8:30 AM - 7:30 PM (IST)";
    if (document.getElementById("cmsContactAddress")) document.getElementById("cmsContactAddress").value = company.address || "";
  }

  // 6. Logo & Visual Branding CMS
  if (company) {
    const currentLogo = company.logo || company.logoWhite || "../assets/logo.png";
    if (document.getElementById("cmsBrandLogoUrl")) document.getElementById("cmsBrandLogoUrl").value = currentLogo;
    if (document.getElementById("cmsBrandName")) document.getElementById("cmsBrandName").value = company.brandName || company.name || "Rayashree Weaving";
    if (document.getElementById("cmsBrandTagline")) document.getElementById("cmsBrandTagline").value = company.tagline || "";
    
    const preview = document.getElementById("cmsBrandLogoPreview");
    if (preview) preview.src = resolveAssetPath(currentLogo);

    const compPreview = document.getElementById("compEditLogoPreview");
    if (compPreview) compPreview.src = resolveAssetPath(currentLogo);
    if (document.getElementById("compEditLogoUrl")) document.getElementById("compEditLogoUrl").value = currentLogo;
  }
}

function saveAllSitePages() {
  const content = getSiteContent();
  const company = getCompanyInfo();

  // Home
  content.home = {
    heroTag: document.getElementById("cmsHomeHeroTag") ? document.getElementById("cmsHomeHeroTag").value.trim() : (content.home.heroTag || ""),
    heroTitle: document.getElementById("cmsHomeHeroTitle") ? document.getElementById("cmsHomeHeroTitle").value.trim() : (content.home.heroTitle || ""),
    heroSubtitle: document.getElementById("cmsHomeHeroSubtitle") ? document.getElementById("cmsHomeHeroSubtitle").value.trim() : (content.home.heroSubtitle || ""),
    stat1Val: document.getElementById("cmsHomeStat1Val") ? document.getElementById("cmsHomeStat1Val").value.trim() : "5M+ Sacks",
    stat1Label: document.getElementById("cmsHomeStat1Label") ? document.getElementById("cmsHomeStat1Label").value.trim() : "Monthly Production Capacity",
    stat2Val: document.getElementById("cmsHomeStat2Val") ? document.getElementById("cmsHomeStat2Val").value.trim() : "48+ Looms",
    stat2Label: document.getElementById("cmsHomeStat2Label") ? document.getElementById("cmsHomeStat2Label").value.trim() : "High-Speed Circular Looms",
    stat3Val: document.getElementById("cmsHomeStat3Val") ? document.getElementById("cmsHomeStat3Val").value.trim() : "350 MT",
    stat3Label: document.getElementById("cmsHomeStat3Label") ? document.getElementById("cmsHomeStat3Label").value.trim() : "Extrusion Tape Line",
    stat4Val: document.getElementById("cmsHomeStat4Val") ? document.getElementById("cmsHomeStat4Val").value.trim() : "100%",
    stat4Label: document.getElementById("cmsHomeStat4Label") ? document.getElementById("cmsHomeStat4Label").value.trim() : "Virgin Polymer & Lab Tested"
  };

  // Products
  content.products = {
    heroTitle: document.getElementById("cmsProductsHeroTitle") ? document.getElementById("cmsProductsHeroTitle").value.trim() : "Complete Manufacturing Portfolio",
    heroSubtitle: document.getElementById("cmsProductsHeroSubtitle") ? document.getElementById("cmsProductsHeroSubtitle").value.trim() : "Explore our full range of heavy-duty HDPE/PP sacks, AD*STAR cement bags, silage tubes, jute packaging, linen fabrics, and 2-ton FIBC containers.",
    customTitle: document.getElementById("cmsProductsCustomTitle") ? document.getElementById("cmsProductsCustomTitle").value.trim() : "Need Bespoke Sizing, GSM or Liner Fit?",
    customDesc: document.getElementById("cmsProductsCustomDesc") ? document.getElementById("cmsProductsCustomDesc").value.trim() : "At Rayashree Weaving, we customize every parameter to match your packing machinery and logistics constraints."
  };

  // About
  content.about = {
    heading: document.getElementById("cmsAboutHeading") ? document.getElementById("cmsAboutHeading").value.trim() : (content.about.heading || ""),
    subheading: document.getElementById("cmsAboutSubheading") ? document.getElementById("cmsAboutSubheading").value.trim() : (content.about.subheading || ""),
    ceoMessage: document.getElementById("cmsAboutCeoMessage") ? document.getElementById("cmsAboutCeoMessage").value.trim() : (content.about.ceoMessage || ""),
    coreVision: document.getElementById("cmsAboutCoreVision") ? document.getElementById("cmsAboutCoreVision").value.trim() : (content.about.coreVision || "")
  };

  // Infra
  content.infrastructure = {
    heading: document.getElementById("cmsInfraHeading") ? document.getElementById("cmsInfraHeading").value.trim() : (content.infrastructure.heading || ""),
    subheading: document.getElementById("cmsInfraSubheading") ? document.getElementById("cmsInfraSubheading").value.trim() : (content.infrastructure.subheading || ""),
    loomsCount: document.getElementById("cmsInfraLoomsCount") ? document.getElementById("cmsInfraLoomsCount").value.trim() : "48+ High-Speed Looms",
    extrusionCapacity: document.getElementById("cmsInfraExtrusion") ? document.getElementById("cmsInfraExtrusion").value.trim() : "350 Metric Tons / Month",
    printingTech: document.getElementById("cmsInfraPrinting") ? document.getElementById("cmsInfraPrinting").value.trim() : "8-Color High-Definition Flexo & Rotogravure BOPP Printing",
    qualityStandards: document.getElementById("cmsInfraQuality") ? document.getElementById("cmsInfraQuality").value.trim() : "Tensile, UV weathering, Drop test, Burst factor tested to IS 14887:2014"
  };

  // Company & Contact
  if (document.getElementById("cmsContactPhone")) {
    const phone = document.getElementById("cmsContactPhone").value.trim();
    company.phone = phone;
    company.whatsappNumber = phone.replace(/[^0-9]/g, "");
  }
  if (document.getElementById("cmsContactCeoName")) company.ceo = document.getElementById("cmsContactCeoName").value.trim();
  if (document.getElementById("cmsContactEmail")) company.email = document.getElementById("cmsContactEmail").value.trim();
  if (document.getElementById("cmsContactHours")) company.hours = document.getElementById("cmsContactHours").value.trim();
  if (document.getElementById("cmsContactAddress")) company.address = document.getElementById("cmsContactAddress").value.trim();

  // Branding & Logo
  const logoUrl = document.getElementById("cmsBrandLogoUrl") ? document.getElementById("cmsBrandLogoUrl").value.trim() : "";
  if (logoUrl) {
    company.logo = logoUrl;
    company.logoWhite = logoUrl;
  }
  if (document.getElementById("cmsBrandName")) {
    company.brandName = document.getElementById("cmsBrandName").value.trim();
    company.name = company.brandName || company.name;
  }
  if (document.getElementById("cmsBrandTagline")) company.tagline = document.getElementById("cmsBrandTagline").value.trim();

  saveSiteContent(content);
  saveCompanyInfo(company);

  renderCompanyProfile();
  renderMetrics();
  renderOperationalAnalytics();

  showAdminToast("All public website pages, branding & contacts updated live!");
}

function resetDefaultSiteContent() {
  if (confirm("Reset all public pages content and branding back to factory defaults?")) {
    localStorage.removeItem("rw_site_content");
    localStorage.removeItem("rw_company_info");
    loadCmsFormValues();
    renderCompanyProfile();
    renderMetrics();
    renderOperationalAnalytics();
    showAdminToast("Public pages content restored to defaults.");
  }
}

/* ==========================================================================
   Company Profile Editor Modal Logic
   ========================================================================== */

function renderCompanyProfile() {
  if (typeof getCompanyInfo !== "function") return;
  const company = getCompanyInfo();
  const products = typeof getProducts === "function" ? getProducts() : [];

  // Update Header Banner
  const headerLogo = document.getElementById("compViewHeaderLogo");
  const headerName = document.getElementById("compViewHeaderLegalName");
  const headerCeo = document.getElementById("compViewHeaderCeo");

  if (headerLogo && (company.logo || company.logoWhite)) {
    headerLogo.src = resolveAssetPath(company.logo || company.logoWhite);
  }
  if (headerName) headerName.textContent = company.name || "RAYASHREE WEAVING PVT. LTD.";
  if (headerCeo) headerCeo.textContent = company.ceo || "Rayashree";

  // Update Corporate Details
  const elLegal = document.getElementById("compViewLegalName");
  const elBrand = document.getElementById("compViewBrandName");
  const elCeo = document.getElementById("compViewCeo");
  const elPhoneLink = document.getElementById("compViewPhoneLink");
  const elWaLink = document.getElementById("compViewWaLink");
  const elEmailLink = document.getElementById("compViewEmailLink");
  const elHours = document.getElementById("compViewHours");
  const elAddress = document.getElementById("compViewAddress");

  if (elLegal) elLegal.textContent = company.name || "RAYASHREE WEAVING PVT. LTD.";
  if (elBrand) elBrand.textContent = company.brandName || "Rayashree Weaving";
  if (elCeo) elCeo.textContent = company.ceo || "Rayashree";

  const cleanPhone = company.phone || "+91 9108713258";
  const numOnly = (company.whatsappNumber || cleanPhone).replace(/[^0-9]/g, "");

  if (elPhoneLink) {
    elPhoneLink.textContent = cleanPhone;
    elPhoneLink.href = `tel:${numOnly}`;
  }
  if (elWaLink) {
    elWaLink.href = `https://wa.me/${numOnly}`;
  }
  if (elEmailLink) {
    elEmailLink.textContent = company.email || "rayashreewpvtltd@gmail.com";
    elEmailLink.href = `mailto:${company.email || "rayashreewpvtltd@gmail.com"}`;
  }
  if (elHours) elHours.textContent = company.hours || "Mon - Sat: 8:30 AM - 7:30 PM (IST)";
  if (elAddress) elAddress.textContent = company.address || "Sy No. 6/10 & 6/1, Kenchanapur Village, Kengeri Hobali, Sulikere Post, BENGALURU-560060, Karnataka, India";

  // Render Dynamic Manufacturing Scope
  const prodCountEl = document.getElementById("compViewProductCount");
  if (prodCountEl) prodCountEl.textContent = products.length;

  const scopeList = document.getElementById("compViewProductScopeList");
  if (scopeList) {
    scopeList.innerHTML = "";
    if (products.length === 0) {
      scopeList.innerHTML = `
        <div style="text-align: center; padding: 2rem 1rem; color: #64748b; background: #ffffff; border-radius: 8px; border: 1px dashed #cbd5e1;">
          <i class="fa-solid fa-boxes-stacked text-gold" style="font-size: 1.75rem; margin-bottom: 0.5rem; display: block;"></i>
          <div style="font-weight: 700; color: #032b27; margin-bottom: 0.25rem;">No Products in Catalog</div>
          <p style="font-size: 0.8rem; margin-bottom: 0.75rem;">Add products in the Product Catalog to automatically populate the company's active manufacturing lines.</p>
          <button class="btn btn-gold btn-sm" onclick="document.getElementById('btnNavProducts').click()">
            <i class="fa-solid fa-plus"></i> Add Products Now
          </button>
        </div>
      `;
    } else {
      products.forEach((p, idx) => {
        const item = document.createElement("div");
        item.style.background = "#ffffff";
        item.style.padding = "0.75rem 0.9rem";
        item.style.borderRadius = "8px";
        item.style.border = "1px solid #e2e8f0";
        item.style.display = "flex";
        item.style.alignItems = "center";
        item.style.justifyContent = "space-between";
        item.style.gap = "0.75rem";

        item.innerHTML = `
          <div style="display: flex; align-items: center; gap: 0.75rem; min-width: 0;">
            <img src="${resolveAssetPath(p.image)}" alt="${p.name}" style="width: 42px; height: 36px; object-fit: cover; border-radius: 6px; border: 1px solid #dfb774; flex-shrink: 0;" onerror="this.src='../assets/images/bags.jpg'">
            <div style="min-width: 0;">
              <div style="font-weight: 700; color: #032b27; font-size: 0.875rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                ${idx + 1}. ${p.name}
              </div>
              <div style="font-size: 0.75rem; color: #64748b; display: flex; gap: 0.5rem; flex-wrap: wrap;">
                <span style="color: #07524a; font-weight: 600;">${p.category || 'General'}</span>
                <span>•</span>
                <span>${p.capacityRange || '50 kg'}</span>
                <span>•</span>
                <span>${p.gsmRange || 'Standard'}</span>
              </div>
            </div>
          </div>
          <button class="btn btn-outline btn-sm" onclick="editProductRow('${p.id}'); document.getElementById('btnNavProducts').click();" style="padding: 0.2rem 0.5rem; font-size: 0.725rem; flex-shrink: 0;" title="Edit in Catalog">
            <i class="fa-solid fa-pen"></i>
          </button>
        `;
        scopeList.appendChild(item);
      });
    }
  }
}

function initCompanyEditor() {
  const form = document.getElementById("companyEditForm");
  const logoFileInput = document.getElementById("compEditLogoFile");
  const logoUrlInput = document.getElementById("compEditLogoUrl");
  const logoPreview = document.getElementById("compEditLogoPreview");

  if (logoFileInput) {
    logoFileInput.addEventListener("change", async (e) => {
      const file = e.target.files[0];
      if (file) {
        try {
          const compressed = await compressImageFile(file, 600, 300, 0.9);
          if (logoPreview) logoPreview.src = compressed;
          if (logoUrlInput) logoUrlInput.value = compressed;
        } catch (err) {
          console.error(err);
        }
      }
    });
  }

  if (logoUrlInput) {
    logoUrlInput.addEventListener("input", (e) => {
      if (logoPreview && e.target.value.trim()) {
        logoPreview.src = resolveAssetPath(e.target.value.trim());
      }
    });
  }

  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const company = getCompanyInfo();

      company.name = document.getElementById("compEditName").value.trim();
      company.ceo = document.getElementById("compEditCeo").value.trim();
      const phone = document.getElementById("compEditPhone").value.trim();
      company.phone = phone;
      company.whatsappNumber = phone.replace(/[^0-9]/g, "");
      company.email = document.getElementById("compEditEmail").value.trim();
      company.hours = document.getElementById("compEditHours").value.trim();
      company.address = document.getElementById("compEditAddress").value.trim();

      const logoUrl = document.getElementById("compEditLogoUrl") ? document.getElementById("compEditLogoUrl").value.trim() : "";
      if (logoUrl) {
        company.logo = logoUrl;
        company.logoWhite = logoUrl;
      }

      saveCompanyInfo(company);
      closeCompanyModal();
      renderCompanyProfile();
      loadCmsFormValues();
      renderMetrics();
      showAdminToast("Company credentials updated and applied live across all pages!");
    });
  }
}

function openCompanyModal() {
  const company = getCompanyInfo();
  const modal = document.getElementById("companyEditModal");
  if (!modal) return;

  if (document.getElementById("compEditName")) document.getElementById("compEditName").value = company.name || "RAYASHREE WEAVING PVT. LTD.";
  if (document.getElementById("compEditCeo")) document.getElementById("compEditCeo").value = company.ceo || "Rayashree";
  if (document.getElementById("compEditPhone")) document.getElementById("compEditPhone").value = company.phone || "+91 9108713258";
  if (document.getElementById("compEditEmail")) document.getElementById("compEditEmail").value = company.email || "rayashreewpvtltd@gmail.com";
  if (document.getElementById("compEditHours")) document.getElementById("compEditHours").value = company.hours || "Mon - Sat: 8:30 AM - 7:30 PM (IST)";
  if (document.getElementById("compEditAddress")) document.getElementById("compEditAddress").value = company.address || "";

  const currentLogo = company.logo || company.logoWhite || "../assets/logo.png";
  if (document.getElementById("compEditLogoUrl")) document.getElementById("compEditLogoUrl").value = currentLogo;
  const preview = document.getElementById("compEditLogoPreview");
  if (preview) preview.src = resolveAssetPath(currentLogo);

  modal.classList.add("active");
}

function closeCompanyModal() {
  const modal = document.getElementById("companyEditModal");
  if (modal) modal.classList.remove("active");
}

window.openStatusModal = openStatusModal;
window.closeStatusModal = closeStatusModal;
window.closeProductModal = closeProductModal;
window.deleteInquiryRow = deleteInquiryRow;
window.editProductRow = editProductRow;
window.deleteProductRow = deleteProductRow;
window.resetDefaultProducts = resetDefaultProducts;
window.openCompanyModal = openCompanyModal;
window.closeCompanyModal = closeCompanyModal;
window.renderCompanyProfile = renderCompanyProfile;
window.saveAllSitePages = saveAllSitePages;
window.resetDefaultSiteContent = resetDefaultSiteContent;
window.initLogoUploader = initLogoUploader;
window.clearAllInquiries = typeof clearAllInquiries === "function" ? clearAllInquiries : () => {};
window.resetTrafficAnalytics = typeof resetTrafficAnalytics === "function" ? resetTrafficAnalytics : () => {};

/* ==========================================================================
   Client Feedback & Testimonials Moderation Management
   ========================================================================== */

function initTestimonialManager() {
  const searchInput = document.getElementById("testimonialSearch");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      testimonialSearchQuery = e.target.value.toLowerCase();
      renderTestimonialsTable();
    });
  }

  const filterPills = document.querySelectorAll(".testimonial-filter-pill");
  filterPills.forEach(pill => {
    pill.addEventListener("click", () => {
      filterPills.forEach(p => p.classList.remove("active"));
      pill.classList.add("active");
      testimonialFilter = pill.getAttribute("data-status");
      renderTestimonialsTable();
    });
  });

  const form = document.getElementById("adminTestimonialForm");
  if (form) {
    form.addEventListener("submit", saveAdminTestimonial);
  }
}

function renderTestimonialsTable() {
  const tbody = document.getElementById("testimonialsTableBody");
  if (!tbody || typeof getTestimonials !== "function") return;

  const allTestimonials = getTestimonials();

  // Update pending count badge on sidebar
  const pendingCount = allTestimonials.filter(t => t.status === "Pending").length;
  const badge = document.getElementById("pendingTestimonialsBadge");
  if (badge) {
    if (pendingCount > 0) {
      badge.textContent = pendingCount;
      badge.style.display = "inline-block";
    } else {
      badge.style.display = "none";
    }
  }

  // Filter items
  let filtered = allTestimonials;
  if (testimonialFilter !== "All") {
    filtered = filtered.filter(t => t.status === testimonialFilter);
  }

  if (testimonialSearchQuery) {
    filtered = filtered.filter(t => 
      (t.author && t.author.toLowerCase().includes(testimonialSearchQuery)) ||
      (t.company && t.company.toLowerCase().includes(testimonialSearchQuery)) ||
      (t.quote && t.quote.toLowerCase().includes(testimonialSearchQuery)) ||
      (t.role && t.role.toLowerCase().includes(testimonialSearchQuery))
    );
  }

  tbody.innerHTML = "";

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; padding: 2.5rem; color: #64748b;">
          <i class="fa-solid fa-comments" style="font-size: 2rem; color: #cbd5e1; margin-bottom: 0.5rem; display: block;"></i>
          No feedback entries match the selected filter.
        </td>
      </tr>
    `;
    return;
  }

  filtered.forEach(item => {
    const tr = document.createElement("tr");

    // Status badge style
    let statusClass = "badge-gray";
    let statusLabel = item.status || "Pending";
    if (item.status === "Approved") {
      statusClass = "badge-emerald";
    } else if (item.status === "Pending") {
      statusClass = "badge-gold";
    } else if (item.status === "Rejected") {
      statusClass = "badge-red";
    }

    // Star rating
    const ratingNum = item.rating || 5;
    let starsHtml = "";
    for (let i = 1; i <= 5; i++) {
      if (i <= ratingNum) {
        starsHtml += `<i class="fa-solid fa-star" style="color: #f59e0b; font-size: 0.75rem;"></i>`;
      } else {
        starsHtml += `<i class="fa-regular fa-star" style="color: #cbd5e1; font-size: 0.75rem;"></i>`;
      }
    }

    tr.innerHTML = `
      <td>
        <div style="font-weight: 700; color: #032b27;">${item.id}</div>
        <div style="font-size: 0.75rem; color: #64748b;">${item.date || 'Recent'}</div>
      </td>
      <td>
        <div style="font-weight: 700; color: #0f172a;">${item.author}</div>
        <div style="font-size: 0.775rem; color: #07524a; font-weight: 600;">${item.role ? item.role + ' • ' : ''}${item.company || ''}</div>
        ${item.email ? `<div style="font-size: 0.725rem; color: #64748b;">${item.email}</div>` : ''}
      </td>
      <td>
        <div>${starsHtml}</div>
        <div style="font-size: 0.725rem; color: #64748b; font-weight: 600; margin-top: 2px;">${ratingNum}/5 Stars</div>
      </td>
      <td style="max-width: 320px;">
        <div style="font-size: 0.85rem; color: #334155; line-height: 1.5; font-style: italic; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical;">
          "${item.quote}"
        </div>
      </td>
      <td>
        <span class="badge ${statusClass}">${statusLabel}</span>
      </td>
      <td>
        <div style="display: flex; gap: 0.35rem; flex-wrap: wrap;">
          ${item.status !== "Approved" ? `
            <button onclick="approveTestimonialItem('${item.id}')" class="btn btn-sm" style="background: #16a34a; color: #fff; padding: 0.25rem 0.5rem; font-size: 0.75rem;" title="Approve for Public Website">
              <i class="fa-solid fa-check"></i> Approve
            </button>
          ` : ''}
          ${item.status !== "Rejected" ? `
            <button onclick="rejectTestimonialItem('${item.id}')" class="btn btn-sm" style="background: #f97316; color: #fff; padding: 0.25rem 0.5rem; font-size: 0.75rem;" title="Reject Feedback">
              <i class="fa-solid fa-xmark"></i> Reject
            </button>
          ` : ''}
          <button onclick="openAdminTestimonialModal('${item.id}')" class="btn btn-outline btn-sm" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" title="Edit Details">
            <i class="fa-solid fa-pen"></i>
          </button>
          <button onclick="deleteTestimonialItem('${item.id}')" class="btn btn-outline btn-sm" style="padding: 0.25rem 0.5rem; font-size: 0.75rem; color: #ef4444; border-color: #fca5a5;" title="Delete Record">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function approveTestimonialItem(id) {
  if (typeof updateTestimonialStatus === "function") {
    updateTestimonialStatus(id, "Approved");
    renderTestimonialsTable();
    showAdminToast("Feedback approved! It is now published live on the public website.");
  }
}

function rejectTestimonialItem(id) {
  if (typeof updateTestimonialStatus === "function") {
    updateTestimonialStatus(id, "Rejected");
    renderTestimonialsTable();
    showAdminToast("Feedback status updated to Rejected.");
  }
}

function deleteTestimonialItem(id) {
  if (confirm("Are you sure you want to delete this client feedback record?")) {
    if (typeof deleteTestimonial === "function") {
      deleteTestimonial(id);
      renderTestimonialsTable();
      showAdminToast("Client feedback entry deleted.");
    }
  }
}

function openAdminTestimonialModal(id = null) {
  const modal = document.getElementById("adminTestimonialModal");
  if (!modal) return;

  const title = document.getElementById("adminTestimonialModalTitle");
  const form = document.getElementById("adminTestimonialForm");
  if (form) form.reset();

  if (id) {
    const testimonials = typeof getTestimonials === "function" ? getTestimonials() : [];
    const item = testimonials.find(t => t.id === id);
    if (item) {
      if (title) title.innerHTML = `<i class="fa-solid fa-comments text-gold"></i> Edit Client Feedback`;
      if (document.getElementById("adminTestimonialId")) document.getElementById("adminTestimonialId").value = item.id;
      if (document.getElementById("adminTestimonialAuthor")) document.getElementById("adminTestimonialAuthor").value = item.author || "";
      if (document.getElementById("adminTestimonialRole")) document.getElementById("adminTestimonialRole").value = item.role || "";
      if (document.getElementById("adminTestimonialCompany")) document.getElementById("adminTestimonialCompany").value = item.company || "";
      if (document.getElementById("adminTestimonialRating")) document.getElementById("adminTestimonialRating").value = item.rating || 5;
      if (document.getElementById("adminTestimonialStatus")) document.getElementById("adminTestimonialStatus").value = item.status || "Approved";
      if (document.getElementById("adminTestimonialQuote")) document.getElementById("adminTestimonialQuote").value = item.quote || "";
    }
  } else {
    if (title) title.innerHTML = `<i class="fa-solid fa-plus text-gold"></i> Add Client Feedback`;
    if (document.getElementById("adminTestimonialId")) document.getElementById("adminTestimonialId").value = "";
    if (document.getElementById("adminTestimonialStatus")) document.getElementById("adminTestimonialStatus").value = "Approved";
  }

  modal.classList.add("active");
}

function closeAdminTestimonialModal() {
  const modal = document.getElementById("adminTestimonialModal");
  if (modal) modal.classList.remove("active");
}

function saveAdminTestimonial(e) {
  e.preventDefault();
  const id = document.getElementById("adminTestimonialId") ? document.getElementById("adminTestimonialId").value : "";
  const author = document.getElementById("adminTestimonialAuthor") ? document.getElementById("adminTestimonialAuthor").value.trim() : "";
  const role = document.getElementById("adminTestimonialRole") ? document.getElementById("adminTestimonialRole").value.trim() : "";
  const company = document.getElementById("adminTestimonialCompany") ? document.getElementById("adminTestimonialCompany").value.trim() : "";
  const rating = document.getElementById("adminTestimonialRating") ? (Number(document.getElementById("adminTestimonialRating").value) || 5) : 5;
  const status = document.getElementById("adminTestimonialStatus") ? document.getElementById("adminTestimonialStatus").value : "Approved";
  const quote = document.getElementById("adminTestimonialQuote") ? document.getElementById("adminTestimonialQuote").value.trim() : "";

  if (!author || !quote) {
    alert("Please provide the client name and feedback quote.");
    return;
  }

  if (id) {
    // Update existing
    updateTestimonial(id, { author, role, company, rating, status, quote });
    showAdminToast("Client feedback updated successfully!");
  } else {
    // Create new (as Approved by default when added by admin)
    const testimonials = getTestimonials();
    const newEntry = {
      id: "TEST-" + Math.floor(1000 + Math.random() * 9000),
      date: new Date().toISOString().slice(0, 10),
      status: status || "Approved",
      rating: rating,
      quote: quote,
      author: author,
      role: role || "Valued Client",
      company: company || "",
      email: ""
    };
    testimonials.unshift(newEntry);
    saveTestimonials(testimonials);
    showAdminToast("New client feedback created successfully!");
  }

  closeAdminTestimonialModal();
  renderTestimonialsTable();
}

window.approveTestimonialItem = approveTestimonialItem;
window.rejectTestimonialItem = rejectTestimonialItem;
window.deleteTestimonialItem = deleteTestimonialItem;
window.openAdminTestimonialModal = openAdminTestimonialModal;
window.closeAdminTestimonialModal = closeAdminTestimonialModal;
window.renderTestimonialsTable = renderTestimonialsTable;


